// TODO: vsavkin add SERVER_PROVIDERS and SERVER_APP_PROVIDERS
export 'package:angular2/src/platform/server/html_adapter.dart';
