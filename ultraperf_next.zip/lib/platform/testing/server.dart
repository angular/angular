// Intentionally blank, the Parse5Adapater bindings for JavaScript don't apply.
