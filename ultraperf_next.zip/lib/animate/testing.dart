library angular2.animate.testing;

export "package:angular2/src/mock/animation_builder_mock.dart";
