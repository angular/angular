/**
 * See [bootstrap] for more information.
 * 
 */
library angular2.bootstrap_static;

export "package:angular2/platform/browser_static.dart" show bootstrapStatic;
export "package:angular2/src/core/angular_entrypoint.dart"
    show AngularEntrypoint;
