/**
 * See [bootstrap] for more information.
 * 
 */
library angular2.bootstrap;

export "package:angular2/platform/browser.dart" show bootstrap;
export "package:angular2/src/core/angular_entrypoint.dart"
    show AngularEntrypoint;
