library angular2.web_worker.worker;

export "../common.dart";
export "../core.dart";
export "../platform/worker_app.dart";
export "../compiler.dart" show UrlResolver;
export "../instrumentation.dart";
export "package:angular2/src/platform/worker_app.dart";
