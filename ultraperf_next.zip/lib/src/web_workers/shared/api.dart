library angular2.src.web_workers.shared.api;

import "package:angular2/src/core/di.dart" show OpaqueToken;

const ON_WEB_WORKER = const OpaqueToken("WebWorker.onWebWorker");
