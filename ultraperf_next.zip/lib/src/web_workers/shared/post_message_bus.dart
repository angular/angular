// PostMessageBus can't be implemented in dart since dart doesn't use postMessage
// This file is only here to prevent ts2dart from trying to transpile the PostMessageBus
library angular2.src.web_workers.shared.post_message_bus;
