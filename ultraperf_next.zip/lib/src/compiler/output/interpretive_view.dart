library angular2.src.compiler.output.interpretive_view;

import "package:angular2/src/facade/lang.dart" show isPresent;
import "package:angular2/src/core/linker/view.dart" show AppView;
import "package:angular2/src/facade/exceptions.dart" show BaseException;
import "output_interpreter.dart" show InstanceFactory, DynamicInstance;

class InterpretiveAppViewInstanceFactory implements InstanceFactory {
  dynamic createInstance(
      dynamic superClass,
      dynamic clazz,
      List<dynamic> args,
      Map<String, dynamic> props,
      Map<String, Function> getters,
      Map<String, Function> methods) {
    if (identical(superClass, AppView)) {
      return new _InterpretiveAppView(args, props, getters, methods);
    }
    throw new BaseException(
        '''Can\'t instantiate class ${ superClass} in interpretative mode''');
  }
}

class _InterpretiveAppView extends AppView<dynamic> implements DynamicInstance {
  Map<String, dynamic> props;
  Map<String, Function> getters;
  Map<String, Function> methods;
  _InterpretiveAppView(
      List<dynamic> args, this.props, this.getters, this.methods)
      : super(args[0], args[1], args[2], args[3], args[4], args[5], args[6],
            args[7], args[8], args[9], args[10]) {
    /* super call moved to initializer */;
  }
  dynamic injectorGet(dynamic token, num nodeIndex, dynamic notFoundResult) {
    var m = this.methods["injectorGet"];
    if (isPresent(m)) {
      return m(token, nodeIndex, notFoundResult);
    } else {
      return super.injectorGet(token, nodeIndex, notFoundResult);
    }
  }

  dynamic injectorPrivateGet(
      dynamic token, num nodeIndex, dynamic notFoundResult) {
    var m = this.methods["injectorPrivateGet"];
    if (isPresent(m)) {
      return m(token, nodeIndex, notFoundResult);
    } else {
      return super.injectorPrivateGet(token, nodeIndex, notFoundResult);
    }
  }

  void destroyInternal() {
    var m = this.methods["destroyInternal"];
    if (isPresent(m)) {
      return m();
    } else {
      return super.destroyInternal();
    }
  }

  void afterContentLifecycleCallbacksInternal() {
    var m = this.methods["afterContentLifecycleCallbacksInternal"];
    if (isPresent(m)) {
      return m();
    } else {
      return super.afterContentLifecycleCallbacksInternal();
    }
  }

  void updateContentQueriesInternal() {
    var m = this.methods["updateContentQueriesInternal"];
    if (isPresent(m)) {
      return m();
    } else {
      return super.updateContentQueriesInternal();
    }
  }

  void afterViewLifecycleCallbacksInternal() {
    var m = this.methods["afterViewLifecycleCallbacksInternal"];
    if (isPresent(m)) {
      return m();
    } else {
      return super.afterViewLifecycleCallbacksInternal();
    }
  }

  void updateViewQueriesInternal() {
    var m = this.methods["updateViewQueriesInternal"];
    if (isPresent(m)) {
      return m();
    } else {
      return super.updateViewQueriesInternal();
    }
  }

  void dirtyParentQueriesInternal() {
    var m = this.methods["dirtyParentQueriesInternal"];
    if (isPresent(m)) {
      return m();
    } else {
      return super.dirtyParentQueriesInternal();
    }
  }

  void detectChangesInInputsInternal() {
    var m = this.methods["detectChangesInInputsInternal"];
    if (isPresent(m)) {
      return m();
    } else {
      return super.detectChangesInInputsInternal();
    }
  }

  void detectChangesHostPropertiesInternal() {
    var m = this.methods["detectChangesHostPropertiesInternal"];
    if (isPresent(m)) {
      return m();
    } else {
      return super.detectChangesHostPropertiesInternal();
    }
  }

  void checkNoChangesInternal() {
    var m = this.methods["checkNoChangesInternal"];
    if (isPresent(m)) {
      return m();
    } else {
      return super.checkNoChangesInternal();
    }
  }
}
