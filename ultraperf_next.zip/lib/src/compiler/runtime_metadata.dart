library angular2.src.compiler.runtime_metadata;

import "package:angular2/src/core/di.dart" show resolveForwardRef;
import "package:angular2/src/facade/lang.dart"
    show
        Type,
        isBlank,
        isPresent,
        isArray,
        stringify,
        isString,
        RegExpWrapper,
        StringWrapper;
import "package:angular2/src/facade/collection.dart" show StringMapWrapper;
import "package:angular2/src/facade/exceptions.dart" show BaseException;
import "package:angular2/src/core/di/exceptions.dart" show NoAnnotationError;
import "compile_metadata.dart" as cpl;
import "package:angular2/src/core/metadata/directives.dart" as md;
import "package:angular2/src/core/metadata/di.dart" as dimd;
import "directive_resolver.dart" show DirectiveResolver;
import "pipe_resolver.dart" show PipeResolver;
import "view_resolver.dart" show ViewResolver;
import "package:angular2/src/core/metadata/view.dart" show ViewMetadata;
import "directive_lifecycle_reflector.dart" show hasLifecycleHook;
import "package:angular2/src/core/metadata/lifecycle_hooks.dart"
    show LifecycleHooks, LIFECYCLE_HOOKS_VALUES;
import "package:angular2/src/core/reflection/reflection.dart" show reflector;
import "package:angular2/src/core/di.dart" show Injectable, Inject, Optional;
import "package:angular2/src/core/platform_directives_and_pipes.dart"
    show PLATFORM_DIRECTIVES, PLATFORM_PIPES;
import "util.dart" show MODULE_SUFFIX;
import "assertions.dart" show assertArrayOfStrings;
import "package:angular2/src/compiler/url_resolver.dart" show getUrlScheme;
import "package:angular2/src/core/di/provider.dart"
    show Provider, constructDependencies, Dependency;
import "package:angular2/src/core/di/metadata.dart"
    show OptionalMetadata, SelfMetadata, HostMetadata, SkipSelfMetadata;
import "package:angular2/src/core/metadata/di.dart" show AttributeMetadata;

@Injectable()
class RuntimeMetadataResolver {
  DirectiveResolver _directiveResolver;
  PipeResolver _pipeResolver;
  ViewResolver _viewResolver;
  List<Type> _platformDirectives;
  List<Type> _platformPipes;
  var _directiveCache = new Map<Type, cpl.CompileDirectiveMetadata>();
  var _pipeCache = new Map<Type, cpl.CompilePipeMetadata>();
  RuntimeMetadataResolver(
      this._directiveResolver,
      this._pipeResolver,
      this._viewResolver,
      @Optional() @Inject(PLATFORM_DIRECTIVES) this._platformDirectives,
      @Optional() @Inject(PLATFORM_PIPES) this._platformPipes) {}
  cpl.CompileDirectiveMetadata getDirectiveMetadata(Type directiveType) {
    var meta = this._directiveCache[directiveType];
    if (isBlank(meta)) {
      var dirMeta = this._directiveResolver.resolve(directiveType);
      var moduleUrl = null;
      var templateMeta = null;
      var changeDetectionStrategy = null;
      var viewProviders = [];
      if (dirMeta is md.ComponentMetadata) {
        assertArrayOfStrings("styles", dirMeta.styles);
        var cmpMeta = (dirMeta as md.ComponentMetadata);
        moduleUrl = calcModuleUrl(directiveType, cmpMeta);
        var viewMeta = this._viewResolver.resolve(directiveType);
        assertArrayOfStrings("styles", viewMeta.styles);
        templateMeta = new cpl.CompileTemplateMetadata(
            encapsulation: viewMeta.encapsulation,
            template: viewMeta.template,
            templateUrl: viewMeta.templateUrl,
            styles: viewMeta.styles,
            styleUrls: viewMeta.styleUrls);
        changeDetectionStrategy = cmpMeta.changeDetection;
        if (isPresent(dirMeta.viewProviders)) {
          viewProviders = this.getProvidersMetadata(dirMeta.viewProviders);
        }
      }
      var providers = [];
      if (isPresent(dirMeta.providers)) {
        providers = this.getProvidersMetadata(dirMeta.providers);
      }
      var queries = [];
      var viewQueries = [];
      if (isPresent(dirMeta.queries)) {
        queries = this.getQueriesMetadata(dirMeta.queries, false);
        viewQueries = this.getQueriesMetadata(dirMeta.queries, true);
      }
      meta = cpl.CompileDirectiveMetadata.create(
          selector: dirMeta.selector,
          exportAs: dirMeta.exportAs,
          isComponent: isPresent(templateMeta),
          type: this.getTypeMetadata(directiveType, moduleUrl),
          template: templateMeta,
          changeDetection: changeDetectionStrategy,
          inputs: dirMeta.inputs,
          outputs: dirMeta.outputs,
          host: dirMeta.host,
          lifecycleHooks: LIFECYCLE_HOOKS_VALUES
              .where((hook) => hasLifecycleHook(hook, directiveType))
              .toList(),
          providers: providers,
          viewProviders: viewProviders,
          queries: queries,
          viewQueries: viewQueries);
      this._directiveCache[directiveType] = meta;
    }
    return meta;
  }

  cpl.CompileTypeMetadata getTypeMetadata(Type type, moduleUrl) {
    return new cpl.CompileTypeMetadata(
        name: runtimeIdentifierName(type),
        moduleUrl: moduleUrl,
        runtime: type,
        diDeps: this.getDependenciesMetadata(type, null));
  }

  cpl.CompileFactoryMetadata getFactoryMetadata(
      Function factory, String moduleUrl) {
    return new cpl.CompileFactoryMetadata(
        name: runtimeIdentifierName(factory),
        moduleUrl: moduleUrl,
        runtime: factory,
        diDeps: this.getDependenciesMetadata(factory, null));
  }

  cpl.CompilePipeMetadata getPipeMetadata(Type pipeType) {
    var meta = this._pipeCache[pipeType];
    if (isBlank(meta)) {
      var pipeMeta = this._pipeResolver.resolve(pipeType);
      var moduleUrl = reflector.importUri(pipeType);
      meta = new cpl.CompilePipeMetadata(
          type: this.getTypeMetadata(pipeType, moduleUrl),
          name: pipeMeta.name,
          pure: pipeMeta.pure,
          lifecycleHooks: LIFECYCLE_HOOKS_VALUES
              .where((hook) => hasLifecycleHook(hook, pipeType))
              .toList());
      this._pipeCache[pipeType] = meta;
    }
    return meta;
  }

  List<cpl.CompileDirectiveMetadata> getViewDirectivesMetadata(Type component) {
    var view = this._viewResolver.resolve(component);
    var directives = flattenDirectives(view, this._platformDirectives);
    for (var i = 0; i < directives.length; i++) {
      if (!isValidType(directives[i])) {
        throw new BaseException(
            '''Unexpected directive value \'${ stringify ( directives [ i ] )}\' on the View of component \'${ stringify ( component )}\'''');
      }
    }
    return directives.map((type) => this.getDirectiveMetadata(type)).toList();
  }

  List<cpl.CompilePipeMetadata> getViewPipesMetadata(Type component) {
    var view = this._viewResolver.resolve(component);
    var pipes = flattenPipes(view, this._platformPipes);
    for (var i = 0; i < pipes.length; i++) {
      if (!isValidType(pipes[i])) {
        throw new BaseException(
            '''Unexpected piped value \'${ stringify ( pipes [ i ] )}\' on the View of component \'${ stringify ( component )}\'''');
      }
    }
    return pipes.map((type) => this.getPipeMetadata(type)).toList();
  }

  List<cpl.CompileDiDependencyMetadata> getDependenciesMetadata(
      dynamic /* Type | Function */ typeOrFunc, List<dynamic> dependencies) {
    List<Dependency> deps;
    try {
      deps = constructDependencies(typeOrFunc, dependencies);
    } catch (e, e_stack) {
      if (e is NoAnnotationError) {
        deps = [];
      } else {
        rethrow;
      }
    }
    return deps.map((dep) {
      var compileToken;
      var p = (dep.properties.firstWhere((p) => p is AttributeMetadata,
          orElse: () => null) as AttributeMetadata);
      var isAttribute = false;
      if (isPresent(p)) {
        compileToken = this.getTokenMetadata(p.attributeName);
        isAttribute = true;
      } else {
        compileToken = this.getTokenMetadata(dep.key.token);
      }
      var compileQuery = null;
      var q = (dep.properties.firstWhere((p) => p is dimd.QueryMetadata,
          orElse: () => null) as dimd.QueryMetadata);
      if (isPresent(q)) {
        compileQuery = this.getQueryMetadata(q, null);
      }
      return new cpl.CompileDiDependencyMetadata(
          isAttribute: isAttribute,
          isHost: dep.upperBoundVisibility is HostMetadata,
          isSelf: dep.upperBoundVisibility is SelfMetadata,
          isSkipSelf: dep.lowerBoundVisibility is SkipSelfMetadata,
          isOptional: dep.optional,
          query: isPresent(q) && !q.isViewQuery ? compileQuery : null,
          viewQuery: isPresent(q) && q.isViewQuery ? compileQuery : null,
          token: compileToken);
    }).toList();
  }

  cpl.CompileIdentifierMetadata getRuntimeIdentifier(dynamic value) {
    return new cpl.CompileIdentifierMetadata(
        runtime: value, name: runtimeIdentifierName(value));
  }

  cpl.CompileTokenMetadata getTokenMetadata(dynamic token) {
    token = resolveForwardRef(token);
    var compileToken;
    if (isString(token)) {
      compileToken = new cpl.CompileTokenMetadata(value: token);
    } else {
      compileToken = new cpl.CompileTokenMetadata(
          identifier: this.getRuntimeIdentifier(token));
    }
    return compileToken;
  }

  List<dynamic /* cpl . CompileProviderMetadata | cpl . CompileTypeMetadata | List < dynamic > */ >
      getProvidersMetadata(List<dynamic> providers) {
    return providers.map((provider) {
      provider = resolveForwardRef(provider);
      if (isArray(provider)) {
        return this.getProvidersMetadata(provider);
      } else if (provider is Provider) {
        return this.getProviderMetadata(provider);
      } else {
        return this.getTypeMetadata(provider, null);
      }
    }).toList();
  }

  cpl.CompileProviderMetadata getProviderMetadata(Provider provider) {
    var compileDeps;
    if (isPresent(provider.useClass)) {
      compileDeps = this
          .getDependenciesMetadata(provider.useClass, provider.dependencies);
    } else if (isPresent(provider.useFactory)) {
      compileDeps = this
          .getDependenciesMetadata(provider.useFactory, provider.dependencies);
    }
    return new cpl.CompileProviderMetadata(
        token: this.getTokenMetadata(provider.token),
        useClass: isPresent(provider.useClass)
            ? this.getTypeMetadata(provider.useClass, null)
            : null,
        useValue: isPresent(provider.useValue)
            ? this.getRuntimeIdentifier(provider.useValue)
            : null,
        useFactory: isPresent(provider.useFactory)
            ? this.getFactoryMetadata(provider.useFactory, null)
            : null,
        useExisting: isPresent(provider.useExisting)
            ? this.getTokenMetadata(provider.useExisting)
            : null,
        deps: compileDeps,
        multi: provider.multi);
  }

  List<cpl.CompileQueryMetadata> getQueriesMetadata(
      Map<String, dimd.QueryMetadata> queries, bool isViewQuery) {
    var compileQueries = [];
    StringMapWrapper.forEach(queries, (query, propertyName) {
      if (identical(query.isViewQuery, isViewQuery)) {
        compileQueries.add(this.getQueryMetadata(query, propertyName));
      }
    });
    return compileQueries;
  }

  cpl.CompileQueryMetadata getQueryMetadata(
      dimd.QueryMetadata q, String propertyName) {
    var selectors;
    if (q.isVarBindingQuery) {
      selectors = q.varBindings
          .map((varName) => this.getTokenMetadata(varName))
          .toList();
    } else {
      selectors = [this.getTokenMetadata(q.selector)];
    }
    return new cpl.CompileQueryMetadata(
        selectors: selectors,
        first: q.first,
        descendants: q.descendants,
        propertyName: propertyName);
  }
}

List<Type> flattenDirectives(
    ViewMetadata view, List<dynamic> platformDirectives) {
  var directives = [];
  if (isPresent(platformDirectives)) {
    flattenArray(platformDirectives, directives);
  }
  if (isPresent(view.directives)) {
    flattenArray(view.directives, directives);
  }
  return directives;
}

List<Type> flattenPipes(ViewMetadata view, List<dynamic> platformPipes) {
  var pipes = [];
  if (isPresent(platformPipes)) {
    flattenArray(platformPipes, pipes);
  }
  if (isPresent(view.pipes)) {
    flattenArray(view.pipes, pipes);
  }
  return pipes;
}

void flattenArray(
    List<dynamic> tree, List<dynamic /* Type | List < dynamic > */ > out) {
  for (var i = 0; i < tree.length; i++) {
    var item = resolveForwardRef(tree[i]);
    if (isArray(item)) {
      flattenArray(item, out);
    } else {
      out.add(item);
    }
  }
}

bool isValidType(Type value) {
  return isPresent(value) && (value is Type);
}

String calcModuleUrl(Type type, md.ComponentMetadata cmpMetadata) {
  var moduleId = cmpMetadata.moduleId;
  if (isPresent(moduleId)) {
    var scheme = getUrlScheme(moduleId);
    return isPresent(scheme) && scheme.length > 0
        ? moduleId
        : '''package:${ moduleId}${ MODULE_SUFFIX}''';
  } else {
    return reflector.importUri(type);
  }
}

String runtimeIdentifierName(dynamic value) {
  var name = stringify(value);
  var parts = StringWrapper.split(name, new RegExp(r'[\s-{]'));
  return parts[0];
}
