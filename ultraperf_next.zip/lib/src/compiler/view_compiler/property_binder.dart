library angular2.src.compiler.view_compiler.property_binder;

import "../expression_parser/ast.dart" as cdAst;
import "../output/output_ast.dart" as o;
import "constants.dart" show Identifiers, AllMethodVars, DetectChangesVars;
import "../template_ast.dart"
    show
        BoundTextAst,
        BoundElementPropertyAst,
        DirectiveAst,
        PropertyBindingType,
        TemplateAst;
import "package:angular2/src/facade/lang.dart" show isBlank, isPresent, isArray;
import "compile_view.dart" show CompileView;
import "compile_element.dart" show CompileElement, CompileNode;
import "compile_method.dart" show CompileMethod;
import "package:angular2/src/core/metadata/lifecycle_hooks.dart"
    show LifecycleHooks;
import "package:angular2/src/core/change_detection/constants.dart"
    show isDefaultChangeDetectionStrategy;
import "../util.dart" show camelCaseToDashCase;
import "expression_converter.dart" show convertCdExpressionToIr;
import "lifecycle_binder.dart"
    show bindDirectiveDetectChangesLifecycleCallbacks;
import "compile_binding.dart" show CompileBinding;

o.ReadVarExpr createBindCurrValueExpr(num exprIndex) {
  return o.variable('''curr_expr_${ exprIndex}''');
}

o.ReadPropExpr createBindFieldExpr(num exprIndex) {
  return o.THIS_EXPR.prop('''_expr_${ exprIndex}''');
}

bind(
    CompileView view,
    o.ReadVarExpr currValueExpr,
    o.ReadPropExpr fieldExpr,
    cdAst.AST parsedExpression,
    o.Expression context,
    List<o.Statement> actions,
    CompileMethod method,
    CompileMethod checkNoChangesMethod) {
  var valueUnwrapperVar = o.variable('''${ currValueExpr . name}_unwrapper''');
  var checkExpression = convertCdExpressionToIr(
      view, context, parsedExpression, valueUnwrapperVar);
  if (isBlank(checkExpression.expression)) {
    // e.g. an empty expression was given
    return;
  }
  view.fields
      .add(new o.ClassField(fieldExpr.name, null, [o.StmtModifier.Private]));
  view.constructorMethod.addStmt(o.THIS_EXPR
      .prop(fieldExpr.name)
      .set(o.importExpr(Identifiers.uninitialized))
      .toStmt());
  if (checkExpression.needsValueUnwrapper) {
    var initValueUnwrapperStmt = valueUnwrapperVar
        .set(o.importExpr(Identifiers.ValueUnwrapper).instantiate([]))
        .toDeclStmt(null, [o.StmtModifier.Final]);
    method.addStmt(initValueUnwrapperStmt);
    checkNoChangesMethod.addStmt(initValueUnwrapperStmt);
  }
  method.addStmt(currValueExpr.set(checkExpression.expression).toDeclStmt());
  checkNoChangesMethod
      .addStmt(currValueExpr.set(checkExpression.expression).toDeclStmt());
  o.Expression condition = o.not(o
      .importExpr(Identifiers.looseIdentical)
      .callFn([fieldExpr, currValueExpr]));
  o.Expression notChangedCondition = o.not(o
      .importExpr(Identifiers.devModeEqual)
      .callFn([fieldExpr, currValueExpr]));
  if (checkExpression.needsValueUnwrapper) {
    condition = valueUnwrapperVar.prop("hasWrappedValue").or(condition);
    notChangedCondition =
        valueUnwrapperVar.prop("hasWrappedValue").or(notChangedCondition);
  }
  method.addStmt(new o.IfStmt(
      condition,
      (new List.from(actions)
        ..addAll([
          (o.THIS_EXPR.prop(fieldExpr.name).set(currValueExpr).toStmt()
              as o.Statement)
        ]))));
  checkNoChangesMethod.addStmt(new o.IfStmt(notChangedCondition, [
    o.THIS_EXPR.callMethod("throwOnChangeError",
        [AllMethodVars.debugContext, fieldExpr, currValueExpr]).toStmt()
  ]));
}

bindRenderText(
    BoundTextAst boundText, CompileNode compileNode, CompileView view) {
  var bindingIndex = view.bindings.length;
  view.bindings.add(new CompileBinding(compileNode, boundText));
  var valueField = createBindFieldExpr(bindingIndex);
  var currValueVar = createBindCurrValueExpr(bindingIndex);
  view.detectChangesInInputsMethod.resetDebugInfo(
      nodeIndex: compileNode.nodeIndex, bindingIndex: bindingIndex);
  view.checkNoChangesMethod.resetDebugInfo(
      nodeIndex: compileNode.nodeIndex, bindingIndex: bindingIndex);
  bind(
      view,
      currValueVar,
      valueField,
      boundText.value,
      o.THIS_EXPR.prop("context"),
      [
        o.THIS_EXPR.prop("renderer").callMethod(
            "setText", [compileNode.renderNode, currValueVar]).toStmt()
      ],
      view.detectChangesInInputsMethod,
      view.checkNoChangesMethod);
}

bindAndWriteToRenderer(List<BoundElementPropertyAst> boundProps,
    o.Expression context, CompileElement compileElement) {
  var view = compileElement.view;
  var renderNode = compileElement.renderNode;
  boundProps.forEach((boundProp) {
    var bindingIndex = view.bindings.length;
    view.bindings.add(new CompileBinding(compileElement, boundProp));
    view.detectChangesHostPropertiesMethod.resetDebugInfo(
        nodeIndex: compileElement.nodeIndex, bindingIndex: bindingIndex);
    view.checkNoChangesMethod.resetDebugInfo(
        nodeIndex: compileElement.nodeIndex, bindingIndex: bindingIndex);
    var valueField = createBindFieldExpr(bindingIndex);
    var currValueVar = createBindCurrValueExpr(bindingIndex);
    String renderMethod;
    o.Expression renderValue = currValueVar;
    var updateStmts = [];
    switch (boundProp.type) {
      case PropertyBindingType.Property:
        renderMethod = "setElementProperty";
        if (view.genConfig.logBindingUpdate) {
          updateStmts.add(
              logBindingUpdateStmt(renderNode, boundProp.name, currValueVar));
        }
        break;
      case PropertyBindingType.Attribute:
        renderMethod = "setElementAttribute";
        renderValue = renderValue
            .isBlank()
            .conditional(o.NULL_EXPR, renderValue.callMethod("toString", []));
        break;
      case PropertyBindingType.Class:
        renderMethod = "setElementClass";
        break;
      case PropertyBindingType.Style:
        renderMethod = "setElementStyle";
        o.Expression strValue = renderValue.callMethod("toString", []);
        if (isPresent(boundProp.unit)) {
          strValue = strValue.plus(o.literal(boundProp.unit));
        }
        renderValue = renderValue.isBlank().conditional(o.NULL_EXPR, strValue);
        break;
    }
    updateStmts.add(o.THIS_EXPR.prop("renderer").callMethod(renderMethod,
        [renderNode, o.literal(boundProp.name), renderValue]).toStmt());
    bind(view, currValueVar, valueField, boundProp.value, context, updateStmts,
        view.detectChangesHostPropertiesMethod, view.checkNoChangesMethod);
  });
}

bindRenderInputs(
    List<BoundElementPropertyAst> boundProps, CompileElement compileElement) {
  return bindAndWriteToRenderer(
      boundProps, o.THIS_EXPR.prop("context"), compileElement);
}

bindDirectiveHostProps(DirectiveAst directiveAst,
    o.Expression directiveInstance, CompileElement compileElement) {
  return bindAndWriteToRenderer(
      directiveAst.hostProperties, directiveInstance, compileElement);
}

bindDirectiveInputs(DirectiveAst directiveAst, o.Expression directiveInstance,
    CompileElement compileElement) {
  var view = compileElement.view;
  var detectChangesInInputsMethod = view.detectChangesInInputsMethod;
  detectChangesInInputsMethod.resetDebugInfo(
      nodeIndex: compileElement.nodeIndex);
  var lifecycleHooks = directiveAst.directive.lifecycleHooks;
  var calcChangesMap =
      !identical(lifecycleHooks.indexOf(LifecycleHooks.OnChanges), -1);
  var isOnPushComp = directiveAst.directive.isComponent &&
      !isDefaultChangeDetectionStrategy(directiveAst.directive.changeDetection);
  if (calcChangesMap) {
    detectChangesInInputsMethod
        .addStmt(DetectChangesVars.changes.set(o.NULL_EXPR).toStmt());
  }
  if (isOnPushComp) {
    detectChangesInInputsMethod
        .addStmt(DetectChangesVars.changed.set(o.literal(false)).toStmt());
  }
  directiveAst.inputs.forEach((input) {
    var bindingIndex = view.bindings.length;
    view.bindings.add(new CompileBinding(compileElement, input));
    detectChangesInInputsMethod.resetDebugInfo(
        nodeIndex: compileElement.nodeIndex, bindingIndex: bindingIndex);
    view.checkNoChangesMethod.resetDebugInfo(
        nodeIndex: compileElement.nodeIndex, bindingIndex: bindingIndex);
    var valueField = createBindFieldExpr(bindingIndex);
    var currValueVar = createBindCurrValueExpr(bindingIndex);
    List<o.Statement> statements = [
      directiveInstance.prop(input.directiveName).set(currValueVar).toStmt()
    ];
    if (calcChangesMap) {
      statements.add(new o.IfStmt(
          DetectChangesVars.changes.identical(o.NULL_EXPR),
          [DetectChangesVars.changes.set(o.literalMap([])).toStmt()]));
      statements.add(DetectChangesVars.changes
          .key(o.literal(input.directiveName))
          .set(o
              .importExpr(Identifiers.SimpleChange)
              .instantiate([valueField, currValueVar]))
          .toStmt());
    }
    if (isOnPushComp) {
      statements.add(DetectChangesVars.changed.set(o.literal(true)).toStmt());
    }
    if (view.genConfig.logBindingUpdate) {
      statements.add(logBindingUpdateStmt(
          compileElement.renderNode, input.directiveName, currValueVar));
    }
    bind(
        view,
        currValueVar,
        valueField,
        input.value,
        o.THIS_EXPR.prop("context"),
        statements,
        detectChangesInInputsMethod,
        view.checkNoChangesMethod);
  });
  bindDirectiveDetectChangesLifecycleCallbacks(directiveAst.directive,
      directiveInstance, DetectChangesVars.changes, compileElement);
  if (isOnPushComp) {
    detectChangesInInputsMethod
        .addStmt(new o.IfStmt(DetectChangesVars.changed, [
      compileElement
          .getOrCreateAppElement()
          .prop("componentView")
          .callMethod("markAsCheckOnce", []).toStmt()
    ]));
  }
}

o.Statement logBindingUpdateStmt(
    o.Expression renderNode, String propName, o.Expression value) {
  return o.THIS_EXPR.prop("renderer").callMethod("setBindingDebugInfo", [
    renderNode,
    o.literal('''ng-reflect-${ camelCaseToDashCase ( propName )}'''),
    value.isBlank().conditional(o.NULL_EXPR, value.callMethod("toString", []))
  ]).toStmt();
}
