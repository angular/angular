library angular2.src.compiler.view_compiler.compile_method;

import "package:angular2/src/facade/lang.dart" show isPresent, isBlank;
import "package:angular2/src/facade/collection.dart"
    show MapWrapper, ListWrapper;
import "../output/output_ast.dart" as o;
import "constants.dart" show Identifiers, AllMethodVars;
import "util.dart" show createDiTokenExpression, getTemplateSource;
import "compile_view.dart" show CompileView;

class _DebugState {
  num nodeIndex;
  num bindingIndex;
  _DebugState(this.nodeIndex, this.bindingIndex) {}
}

var NULL_DEBUG_STATE = new _DebugState(null, null);

class CompileMethod {
  CompileView _view;
  String _displayName;
  _DebugState _currState = NULL_DEBUG_STATE;
  _DebugState _newState = NULL_DEBUG_STATE;
  bool _debugEnabled;
  bool _hasDebugStmts = false;
  List<o.Statement> _bodyStatements = [];
  List<o.Statement> _errorStatements = [];
  CompileMethod(this._view, this._displayName) {
    this._debugEnabled = this._view.genConfig.genDebugInfo;
  }
  _updateDebugContextIfNeeded() {
    if (!identical(this._newState.nodeIndex, this._currState.nodeIndex) ||
        !identical(this._newState.bindingIndex, this._currState.bindingIndex)) {
      if (isPresent(this._newState.nodeIndex)) {
        this._bodyStatements.add(new o.CommentStmt(
            '''${ getTemplateSource ( this . _view . nodes [ this . _newState . nodeIndex ] . sourceAst )}'''));
      }
      if (this._debugEnabled) {
        this._bodyStatements.add(AllMethodVars.debugContext
            .set(o.THIS_EXPR.callMethod("debugContext", [
              o.literal(this._newState.nodeIndex),
              o.literal(this._newState.bindingIndex)
            ]))
            .toStmt());
      }
      this._hasDebugStmts = true;
      this._currState = this._newState;
    }
  }

  resetDebugInfo({nodeIndex: null, bindingIndex: null}) {
    this._newState = new _DebugState(nodeIndex, bindingIndex);
  }

  addStmt(o.Statement stmt) {
    this._updateDebugContextIfNeeded();
    this._bodyStatements.add(stmt);
  }

  addStmts(List<o.Statement> stmts) {
    this._updateDebugContextIfNeeded();
    ListWrapper.addAll(this._bodyStatements, stmts);
  }

  addDebugErrorStmt(o.Statement stmt) {
    this._errorStatements.add(stmt);
  }

  List<o.Statement> finish() {
    if (this._debugEnabled && this._hasDebugStmts) {
      var errorStmts = (new List.from(this._errorStatements)
        ..addAll([
          o.THIS_EXPR.callMethod("rethrowWithContext", [
            o.literal(this._displayName),
            AllMethodVars.debugContext,
            o.CATCH_ERROR_VAR,
            o.CATCH_STACK_VAR
          ]).toStmt()
        ]));
      return [
        AllMethodVars.debugContext
            .set(o.THIS_EXPR
                .callMethod("debugContext", [o.NULL_EXPR, o.NULL_EXPR]))
            .toDeclStmt(new o.ExternalType(Identifiers.DebugContext)),
        new o.TryCatchStmt(this._bodyStatements, errorStmts)
      ];
    } else {
      return this._bodyStatements;
    }
  }
}
