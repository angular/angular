library angular2.src.compiler.view_compiler.compile_view;

import "package:angular2/src/facade/lang.dart" show isPresent, isBlank;
import "package:angular2/src/facade/collection.dart"
    show ListWrapper, StringMapWrapper;
import "../output/output_ast.dart" as o;
import "constants.dart" show Identifiers, EventHandlerVars;
import "compile_query.dart" show CompileQuery, createQueryList;
import "expression_converter.dart" show NameResolver;
import "compile_element.dart" show CompileElement, CompileNode;
import "compile_method.dart" show CompileMethod;
import "package:angular2/src/core/linker/view_type.dart" show ViewType;
import "../compile_metadata.dart"
    show
        CompileDirectiveMetadata,
        CompilePipeMetadata,
        CompileIdentifierMetadata;
import "../template_ast.dart" show TemplateAst, templateVisitAll;
import "util.dart"
    show
        getViewFactoryName,
        injectFromViewParentInjector,
        getTemplateSource,
        identifierToken,
        createDiTokenExpression,
        getPropertyInView;
import "../config.dart" show CompilerConfig;
import "compile_binding.dart" show CompileBinding;
import "lifecycle_binder.dart" show bindPipeDestroyLifecycleCallbacks;

class CompilePipe {
  CompilePipe() {}
}

class CompileView implements NameResolver {
  CompileDirectiveMetadata component;
  CompilerConfig genConfig;
  List<CompilePipeMetadata> pipeMetas;
  o.Expression styles;
  num viewIndex;
  CompileElement declarationElement;
  List<List<String>> templateVariableBindings;
  ViewType viewType;
  List<CompileQuery> viewQueries;
  List<List<dynamic /* String | o . Expression */ >> namedAppElements = [];
  List<CompileNode> nodes = [];
  List<o.Expression> rootNodesOrAppElements = [];
  List<CompileBinding> bindings = [];
  List<o.Statement> classStatements = [];
  CompileMethod constructorMethod;
  CompileMethod injectorGetMethod;
  CompileMethod injectorPrivateGetMethod;
  CompileMethod updateContentQueriesMethod;
  CompileMethod dirtyParentQueriesMethod;
  CompileMethod updateViewQueriesMethod;
  CompileMethod detectChangesInInputsMethod;
  CompileMethod detectChangesHostPropertiesMethod;
  CompileMethod checkNoChangesMethod;
  CompileMethod afterContentLifecycleCallbacksMethod;
  CompileMethod afterViewLifecycleCallbacksMethod;
  CompileMethod destroyMethod;
  List<o.ClassMethod> eventHandlerMethods = [];
  List<o.ClassField> fields = [];
  List<o.ClassGetter> getters = [];
  List<o.Expression> disposables = [];
  List<o.Expression> subscriptions = [];
  CompileView componentView;
  List<CompileError> compileErrors;
  var pipes = new Map<String, o.Expression>();
  var variables = new Map<String, o.Expression>();
  String className;
  o.Type classType;
  o.ReadVarExpr viewFactory;
  CompileView(this.component, this.genConfig, this.pipeMetas, this.styles,
      this.viewIndex, this.declarationElement, this.templateVariableBindings) {
    this.constructorMethod = new CompileMethod(this, "create");
    this.injectorGetMethod = new CompileMethod(this, "injectorGet");
    this.injectorPrivateGetMethod =
        new CompileMethod(this, "injectorPrivateGet");
    this.updateContentQueriesMethod = new CompileMethod(this, "updateQueries");
    this.dirtyParentQueriesMethod = new CompileMethod(this, "updateQueries");
    this.updateViewQueriesMethod = new CompileMethod(this, "updateQueries");
    this.detectChangesInInputsMethod = new CompileMethod(this, "detectChanges");
    this.detectChangesHostPropertiesMethod =
        new CompileMethod(this, "detectChanges");
    this.checkNoChangesMethod = new CompileMethod(this, "checkNoChanges");
    this.afterContentLifecycleCallbacksMethod =
        new CompileMethod(this, "detectChanges");
    this.afterViewLifecycleCallbacksMethod =
        new CompileMethod(this, "detectChanges");
    this.destroyMethod = new CompileMethod(this, "destroy");
    this.viewType = getViewType(component, viewIndex);
    this.className = '''_View_${ component . type . name}${ viewIndex}''';
    this.classType =
        o.importType(new CompileIdentifierMetadata(name: this.className));
    this.viewFactory = o.variable(getViewFactoryName(component, viewIndex));
    if (identical(this.viewType, ViewType.COMPONENT) ||
        identical(this.viewType, ViewType.HOST)) {
      this.componentView = this;
      this.compileErrors = [];
    } else {
      this.componentView = this.declarationElement.view.componentView;
      this.compileErrors = this.componentView.compileErrors;
    }
    var viewQueries = [];
    if (identical(this.viewType, ViewType.COMPONENT)) {
      var directiveInstance = o.THIS_EXPR.prop("context");
      this.component.viewQueries.forEach((queryMeta) {
        var propName =
            '''_viewQuery_${ queryMeta . selectors [ 0 ] . name}_${ viewQueries . length}''';
        var queryList =
            createQueryList(queryMeta, directiveInstance, propName, this);
        var query =
            new CompileQuery(queryMeta, queryList, directiveInstance, this);
        viewQueries.add(query);
      });
      var constructorViewQueryCount = 0;
      this.component.type.diDeps.forEach((dep) {
        if (isPresent(dep.viewQuery)) {
          var queryList = o.THIS_EXPR
              .prop("declarationAppElement")
              .prop("componentConstructorViewQueries")
              .key(o.literal(constructorViewQueryCount++));
          var query = new CompileQuery(
              dep.viewQuery, queryList, directiveInstance, this);
          viewQueries.add(query);
        }
      });
    }
    this.viewQueries = viewQueries;
    templateVariableBindings.forEach((entry) {
      this.variables[entry[1]] =
          o.THIS_EXPR.prop("locals").key(o.literal(entry[0]));
    });
    if (!this.declarationElement.isNull()) {
      this.declarationElement.setEmbeddedView(this);
    }
  }
  o.Expression createPipe(String name) {
    CompilePipeMetadata pipeMeta = this
        .pipeMetas
        .firstWhere((pipeMeta) => pipeMeta.name == name, orElse: () => null);
    var pipeFieldName = pipeMeta.pure
        ? '''_pipe_${ name}'''
        : '''_pipe_${ name}_${ this . pipes . length}''';
    var pipeExpr = this.pipes[pipeFieldName];
    if (isBlank(pipeExpr)) {
      var deps = pipeMeta.type.diDeps.map((diDep) {
        if (diDep.token
            .equalsTo(identifierToken(Identifiers.ChangeDetectorRef))) {
          return o.THIS_EXPR.prop("ref");
        }
        return injectFromViewParentInjector(diDep.token, false);
      }).toList();
      this.fields.add(new o.ClassField(pipeFieldName,
          o.importType(pipeMeta.type), [o.StmtModifier.Private]));
      this.constructorMethod.resetDebugInfo();
      this.constructorMethod.addStmt(o.THIS_EXPR
          .prop(pipeFieldName)
          .set(o.importExpr(pipeMeta.type).instantiate(deps))
          .toStmt());
      pipeExpr = o.THIS_EXPR.prop(pipeFieldName);
      this.pipes[pipeFieldName] = pipeExpr;
      bindPipeDestroyLifecycleCallbacks(pipeMeta, pipeExpr, this);
    }
    return pipeExpr;
  }

  o.Expression getVariable(String name) {
    if (name == EventHandlerVars.event.name) {
      return EventHandlerVars.event;
    }
    CompileView currView = this;
    var result = currView.variables[name];
    var viewPath = [];
    while (isBlank(result) && isPresent(currView.declarationElement.view)) {
      currView = currView.declarationElement.view;
      result = currView.variables[name];
      viewPath.add(currView);
    }
    if (isPresent(result)) {
      return getPropertyInView(result, viewPath);
    } else {
      return null;
    }
  }

  afterNodes() {
    this.viewQueries.forEach((query) {
      query.afterChildren(this.updateViewQueriesMethod);
    });
  }

  addError(CompileError error) {
    this.compileErrors.add(error);
  }
}

class CompileError {
  String message;
  TemplateAst location;
  CompileError(this.message, this.location) {}
  String toString() {
    return '''${ this . message} in ${ getTemplateSource ( this . location )}''';
  }
}

ViewType getViewType(
    CompileDirectiveMetadata component, num embeddedTemplateIndex) {
  if (embeddedTemplateIndex > 0) {
    return ViewType.EMBEDDED;
  } else if (component.type.isHost) {
    return ViewType.HOST;
  } else {
    return ViewType.COMPONENT;
  }
}
