library angular2.src.compiler.view_compiler.constants;

import "package:angular2/src/facade/lang.dart"
    show serializeEnum, isBlank, resolveEnumToken;
import "../compile_metadata.dart"
    show CompileIdentifierMetadata, CompileTokenMetadata;
import "package:angular2/src/core/linker/view.dart"
    show AppView, HOST_VIEW_ELEMENT_NAME;
import "package:angular2/src/core/linker/debug_context.dart"
    show StaticNodeDebugInfo, StaticBindingDebugInfo, DebugContext;
import "package:angular2/src/core/linker/view_utils.dart"
    show flattenNestedViewRenderNodes, ensureSlotCount, interpolate;
import "package:angular2/src/core/change_detection/change_detection.dart"
    show
        uninitialized,
        devModeEqual,
        looseIdentical,
        SimpleChange,
        ValueUnwrapper,
        ChangeDetectorRef,
        ChangeDetectorState,
        ChangeDetectionStrategy;
import "package:angular2/src/core/linker/view_manager.dart"
    show AppViewManager_;
import "package:angular2/src/core/linker/element.dart" show AppElement;
import "package:angular2/src/core/linker/element_ref.dart" show ElementRef;
import "package:angular2/src/core/linker/view_container_ref.dart"
    show ViewContainerRef;
import "package:angular2/src/core/render/api.dart"
    show Renderer, RenderComponentType, RenderDebugInfo;
import "package:angular2/src/core/metadata/view.dart" show ViewEncapsulation;
import "package:angular2/src/core/linker/view_type.dart" show ViewType;
import "package:angular2/src/core/linker.dart" show QueryList;
import "package:angular2/src/core/di/injector.dart" show Injector;
import "package:angular2/src/core/linker/template_ref.dart"
    show TemplateRef, TemplateRef_;
import "../util.dart" show MODULE_SUFFIX;
import "../output/output_ast.dart" as o;

var APP_VIEW_MODULE_URL =
    "asset:angular2/lib/src/core/linker/view" + MODULE_SUFFIX;
var VIEW_UTILS_MODULE_URL =
    "asset:angular2/lib/src/core/linker/view_utils" + MODULE_SUFFIX;
var CD_MODULE_URL =
    "asset:angular2/lib/src/core/change_detection/change_detection" +
        MODULE_SUFFIX;
// Reassign the imports to different variables so we can

// define static variables with the name of the import.

// (only needed for Dart).
var impAppViewManager_ = AppViewManager_;
var impAppView = AppView;
var impDebugContext = DebugContext;
var impAppElement = AppElement;
var impElementRef = ElementRef;
var impViewContainerRef = ViewContainerRef;
var impChangeDetectorRef = ChangeDetectorRef;
var impRenderComponentType = RenderComponentType;
var impQueryList = QueryList;
var impTemplateRef = TemplateRef;
var impTemplateRef_ = TemplateRef_;
var impValueUnwrapper = ValueUnwrapper;
var impInjector = Injector;
var impViewEncapsulation = ViewEncapsulation;
var impViewType = ViewType;
var impChangeDetectionStrategy = ChangeDetectionStrategy;
var impStaticNodeDebugInfo = StaticNodeDebugInfo;
var impStaticBindingDebugInfo = StaticBindingDebugInfo;
var impRenderer = Renderer;
var impSimpleChange = SimpleChange;
var impUninitialized = uninitialized;
var impChangeDetectorState = ChangeDetectorState;
var impEnsureSlotCount = ensureSlotCount;
var impFlattenNestedViewRenderNodes = flattenNestedViewRenderNodes;
var impLooseIdentical = looseIdentical;
var impDevModeEqual = devModeEqual;
var impInterpolate = interpolate;

class Identifiers {
  static var AppViewManager_ = new CompileIdentifierMetadata(
      name: "AppViewManager_",
      moduleUrl:
          "asset:angular2/lib/src/core/linker/view_manager" + MODULE_SUFFIX,
      runtime: impAppViewManager_);
  static var AppView = new CompileIdentifierMetadata(
      name: "AppView", moduleUrl: APP_VIEW_MODULE_URL, runtime: impAppView);
  static var AppElement = new CompileIdentifierMetadata(
      name: "AppElement",
      moduleUrl: "asset:angular2/lib/src/core/linker/element" + MODULE_SUFFIX,
      runtime: impAppElement);
  static var ElementRef = new CompileIdentifierMetadata(
      name: "ElementRef",
      moduleUrl:
          "asset:angular2/lib/src/core/linker/element_ref" + MODULE_SUFFIX,
      runtime: impElementRef);
  static var ViewContainerRef = new CompileIdentifierMetadata(
      name: "ViewContainerRef",
      moduleUrl: "asset:angular2/lib/src/core/linker/view_container_ref" +
          MODULE_SUFFIX,
      runtime: impViewContainerRef);
  static var ChangeDetectorRef = new CompileIdentifierMetadata(
      name: "ChangeDetectorRef",
      moduleUrl:
          "asset:angular2/lib/src/core/change_detection/change_detector_ref" +
              MODULE_SUFFIX,
      runtime: impChangeDetectorRef);
  static var RenderComponentType = new CompileIdentifierMetadata(
      name: "RenderComponentType",
      moduleUrl: "asset:angular2/lib/src/core/render/api" + MODULE_SUFFIX,
      runtime: impRenderComponentType);
  static var QueryList = new CompileIdentifierMetadata(
      name: "QueryList",
      moduleUrl:
          "asset:angular2/lib/src/core/linker/query_list" + MODULE_SUFFIX,
      runtime: impQueryList);
  static var TemplateRef = new CompileIdentifierMetadata(
      name: "TemplateRef",
      moduleUrl:
          "asset:angular2/lib/src/core/linker/template_ref" + MODULE_SUFFIX,
      runtime: impTemplateRef);
  static var TemplateRef_ = new CompileIdentifierMetadata(
      name: "TemplateRef_",
      moduleUrl:
          "asset:angular2/lib/src/core/linker/template_ref" + MODULE_SUFFIX,
      runtime: impTemplateRef_);
  static var ValueUnwrapper = new CompileIdentifierMetadata(
      name: "ValueUnwrapper",
      moduleUrl: CD_MODULE_URL,
      runtime: impValueUnwrapper);
  static var Injector = new CompileIdentifierMetadata(
      name: "Injector",
      moduleUrl: '''asset:angular2/lib/src/core/di/injector${ MODULE_SUFFIX}''',
      runtime: impInjector);
  static var ViewEncapsulation = new CompileIdentifierMetadata(
      name: "ViewEncapsulation",
      moduleUrl: "asset:angular2/lib/src/core/metadata/view" + MODULE_SUFFIX,
      runtime: impViewEncapsulation);
  static var ViewType = new CompileIdentifierMetadata(
      name: "ViewType",
      moduleUrl:
          '''asset:angular2/lib/src/core/linker/view_type${ MODULE_SUFFIX}''',
      runtime: impViewType);
  static var ChangeDetectionStrategy = new CompileIdentifierMetadata(
      name: "ChangeDetectionStrategy",
      moduleUrl: CD_MODULE_URL,
      runtime: impChangeDetectionStrategy);
  static var StaticNodeDebugInfo = new CompileIdentifierMetadata(
      name: "StaticNodeDebugInfo",
      moduleUrl:
          '''asset:angular2/lib/src/core/linker/debug_context${ MODULE_SUFFIX}''',
      runtime: impStaticNodeDebugInfo);
  static var StaticBindingDebugInfo = new CompileIdentifierMetadata(
      name: "StaticBindingDebugInfo",
      moduleUrl:
          '''asset:angular2/lib/src/core/linker/debug_context${ MODULE_SUFFIX}''',
      runtime: impStaticBindingDebugInfo);
  static var DebugContext = new CompileIdentifierMetadata(
      name: "DebugContext",
      moduleUrl:
          '''asset:angular2/lib/src/core/linker/debug_context${ MODULE_SUFFIX}''',
      runtime: impDebugContext);
  static var Renderer = new CompileIdentifierMetadata(
      name: "Renderer",
      moduleUrl: "asset:angular2/lib/src/core/render/api" + MODULE_SUFFIX,
      runtime: impRenderer);
  static var SimpleChange = new CompileIdentifierMetadata(
      name: "SimpleChange", moduleUrl: CD_MODULE_URL, runtime: impSimpleChange);
  static var uninitialized = new CompileIdentifierMetadata(
      name: "uninitialized",
      moduleUrl: CD_MODULE_URL,
      runtime: impUninitialized);
  static var ChangeDetectorState = new CompileIdentifierMetadata(
      name: "ChangeDetectorState",
      moduleUrl: CD_MODULE_URL,
      runtime: impChangeDetectorState);
  static var ensureSlotCount = new CompileIdentifierMetadata(
      name: "ensureSlotCount",
      moduleUrl: VIEW_UTILS_MODULE_URL,
      runtime: impEnsureSlotCount);
  static var flattenNestedViewRenderNodes = new CompileIdentifierMetadata(
      name: "flattenNestedViewRenderNodes",
      moduleUrl: VIEW_UTILS_MODULE_URL,
      runtime: impFlattenNestedViewRenderNodes);
  static var looseIdentical = new CompileIdentifierMetadata(
      name: "looseIdentical",
      moduleUrl: CD_MODULE_URL,
      runtime: impLooseIdentical);
  static var devModeEqual = new CompileIdentifierMetadata(
      name: "devModeEqual", moduleUrl: CD_MODULE_URL, runtime: impDevModeEqual);
  static var interpolate = new CompileIdentifierMetadata(
      name: "interpolate",
      moduleUrl: VIEW_UTILS_MODULE_URL,
      runtime: impInterpolate);
}

o.Expression _enumExpression(
    CompileIdentifierMetadata classIdentifier, dynamic value) {
  if (isBlank(value)) return o.NULL_EXPR;
  var name = resolveEnumToken(classIdentifier.runtime, value);
  return o.importExpr(new CompileIdentifierMetadata(
      name: '''${ classIdentifier . name}.${ name}''',
      moduleUrl: classIdentifier.moduleUrl,
      runtime: value));
}

class ViewTypeEnum {
  static o.Expression fromValue(ViewType value) {
    return _enumExpression(Identifiers.ViewType, value);
  }

  static var HOST = ViewTypeEnum.fromValue(ViewType.HOST);
  static var COMPONENT = ViewTypeEnum.fromValue(ViewType.COMPONENT);
  static var EMBEDDED = ViewTypeEnum.fromValue(ViewType.EMBEDDED);
}

class ViewEncapsulationEnum {
  static o.Expression fromValue(ViewEncapsulation value) {
    return _enumExpression(Identifiers.ViewEncapsulation, value);
  }

  static var Emulated =
      ViewEncapsulationEnum.fromValue(ViewEncapsulation.Emulated);
  static var Native = ViewEncapsulationEnum.fromValue(ViewEncapsulation.Native);
  static var None = ViewEncapsulationEnum.fromValue(ViewEncapsulation.None);
}

class ChangeDetectorStateEnum {
  static o.Expression fromValue(ChangeDetectorState value) {
    return _enumExpression(Identifiers.ChangeDetectorState, value);
  }

  static var NeverChecked =
      ChangeDetectorStateEnum.fromValue(ChangeDetectorState.NeverChecked);
  static var CheckedBefore =
      ChangeDetectorStateEnum.fromValue(ChangeDetectorState.CheckedBefore);
  static var Errored =
      ChangeDetectorStateEnum.fromValue(ChangeDetectorState.Errored);
}

class ChangeDetectionStrategyEnum {
  static o.Expression fromValue(ChangeDetectionStrategy value) {
    return _enumExpression(Identifiers.ChangeDetectionStrategy, value);
  }

  static var CheckOnce =
      ChangeDetectionStrategyEnum.fromValue(ChangeDetectionStrategy.CheckOnce);
  static var Checked =
      ChangeDetectionStrategyEnum.fromValue(ChangeDetectionStrategy.Checked);
  static var CheckAlways = ChangeDetectionStrategyEnum
      .fromValue(ChangeDetectionStrategy.CheckAlways);
  static var Detached =
      ChangeDetectionStrategyEnum.fromValue(ChangeDetectionStrategy.Detached);
  static var OnPush =
      ChangeDetectionStrategyEnum.fromValue(ChangeDetectionStrategy.OnPush);
  static var Default =
      ChangeDetectionStrategyEnum.fromValue(ChangeDetectionStrategy.Default);
}

class ViewConstructorVars {
  static var renderer = o.variable("renderer");
  static var viewManager = o.variable("viewManager");
  static var projectableNodes = o.variable('''projectableNodes''');
  static var parentInjector = o.variable("parentInjector");
  static var declarationEl = o.variable("declarationEl");
  static var rootSelector = o.variable("rootSelector");
  static var parentRenderNode = o.variable("parentRenderNode");
}

class EventHandlerVars {
  static var event = o.variable("\$event");
}

class AllMethodVars {
  static var debugContext = o.variable("debugContext");
}

class InjectMethodVars {
  static var token = o.variable("token");
  static var requestNodeIndex = o.variable("requestNodeIndex");
  static var notFoundResult = o.variable("notFoundResult");
}

class DetectChangesVars {
  static var changes = o.variable('''changes''');
  static var changed = o.variable('''changed''');
}
