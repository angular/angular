library angular2.src.compiler.view_compiler.view_compiler;

import "package:angular2/src/facade/exceptions.dart" show BaseException;
import "package:angular2/src/core/di.dart" show Injectable;
import "../output/output_ast.dart" as o;
import "compile_element.dart" show CompileElement;
import "compile_view.dart" show CompileView;
import "view_builder.dart" show buildView, ViewCompileDependency;
import "../compile_metadata.dart"
    show CompileDirectiveMetadata, CompilePipeMetadata;
import "../template_ast.dart" show TemplateAst;
import "../config.dart" show CompilerConfig;

class ViewCompileResult {
  List<o.Statement> statements;
  String viewFactoryVar;
  List<ViewCompileDependency> dependencies;
  ViewCompileResult(this.statements, this.viewFactoryVar, this.dependencies) {}
}

@Injectable()
class ViewCompiler {
  CompilerConfig _genConfig;
  ViewCompiler(this._genConfig) {}
  ViewCompileResult compileComponent(
      CompileDirectiveMetadata component,
      List<TemplateAst> template,
      o.Expression styles,
      List<CompilePipeMetadata> pipes) {
    var statements = [];
    var dependencies = [];
    var view = new CompileView(component, this._genConfig, pipes, styles, 0,
        CompileElement.createNull(), []);
    buildView(view, template, dependencies, statements);
    if (view.compileErrors.length > 0) {
      throw new BaseException('''Compile errror in ${ component . type . name}:
${ view . compileErrors . join ( "\n" )}''');
    }
    return new ViewCompileResult(
        statements, view.viewFactory.name, dependencies);
  }
}
