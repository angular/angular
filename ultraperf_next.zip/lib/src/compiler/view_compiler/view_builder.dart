library angular2.src.compiler.view_compiler.view_builder;

import "package:angular2/src/facade/lang.dart" show isPresent, StringWrapper;
import "package:angular2/src/facade/collection.dart"
    show ListWrapper, StringMapWrapper, SetWrapper;
import "../output/output_ast.dart" as o;
import "constants.dart"
    show
        Identifiers,
        AllMethodVars,
        ViewConstructorVars,
        InjectMethodVars,
        DetectChangesVars,
        ViewTypeEnum,
        ViewEncapsulationEnum,
        ChangeDetectionStrategyEnum;
import "compile_view.dart" show CompileView;
import "compile_element.dart" show CompileElement, CompileNode;
import "../template_ast.dart"
    show
        TemplateAst,
        TemplateAstVisitor,
        NgContentAst,
        EmbeddedTemplateAst,
        ElementAst,
        VariableAst,
        BoundEventAst,
        BoundElementPropertyAst,
        AttrAst,
        BoundTextAst,
        TextAst,
        DirectiveAst,
        BoundDirectivePropertyAst,
        templateVisitAll,
        PropertyBindingType,
        ProviderAst;
import "util.dart"
    show
        getViewFactoryName,
        createFlatArray,
        identifierToken,
        getTemplateSource,
        createDiTokenExpression;
import "package:angular2/src/core/linker/view_type.dart" show ViewType;
import "package:angular2/src/core/metadata/view.dart" show ViewEncapsulation;
import "package:angular2/src/core/linker/view.dart" show HOST_VIEW_ELEMENT_NAME;
import "../compile_metadata.dart"
    show
        CompileIdentifierMetadata,
        CompileDirectiveMetadata,
        CompileTokenMetadata;
import "view_binder.dart" show bindView;
import "compile_binding.dart" show CompileBinding;

const IMPLICIT_TEMPLATE_VAR = "\$implicit";
const CLASS_ATTR = "class";
const STYLE_ATTR = "style";

class ViewCompileDependency {
  CompileDirectiveMetadata comp;
  CompileIdentifierMetadata factoryPlaceholder;
  ViewCompileDependency(this.comp, this.factoryPlaceholder) {}
}

num buildView(
    CompileView view,
    List<TemplateAst> template,
    List<ViewCompileDependency> targetDependencies,
    List<o.Statement> targetStatements) {
  var builderVisitor =
      new ViewBuilderVisitor(view, targetDependencies, targetStatements);
  templateVisitAll(
      builderVisitor,
      template,
      view.declarationElement.isNull()
          ? view.declarationElement
          : view.declarationElement.parent);
  // Need to separate binding from creation to be able to refer to

  // variables that have been declared after usage.
  bindView(view, template);
  view.afterNodes();
  createViewTopLevelStmts(view, targetStatements);
  return builderVisitor.nestedViewCount;
}

class ViewBuilderVisitor implements TemplateAstVisitor {
  CompileView view;
  List<ViewCompileDependency> targetDependencies;
  List<o.Statement> targetStatements;
  num nestedViewCount = 0;
  ViewBuilderVisitor(
      this.view, this.targetDependencies, this.targetStatements) {}
  bool _isRootNode(CompileElement parent) {
    return !identical(parent.view, this.view);
  }

  _addRootNodeAndProject(
      CompileNode node, num ngContentIndex, CompileElement parent) {
    var appEl = node is CompileElement ? node.getOptionalAppElement() : null;
    if (this._isRootNode(parent)) {
      // store root nodes only for embedded/host views
      if (!identical(this.view.viewType, ViewType.COMPONENT)) {
        this
            .view
            .rootNodesOrAppElements
            .add(isPresent(appEl) ? appEl : node.renderNode);
      }
    } else if (isPresent(parent.component) && isPresent(ngContentIndex)) {
      parent.addContentNode(
          ngContentIndex, isPresent(appEl) ? appEl : node.renderNode);
    }
  }

  o.Expression _getParentRenderNode(CompileElement parent) {
    if (this._isRootNode(parent)) {
      if (identical(this.view.viewType, ViewType.COMPONENT)) {
        return ViewConstructorVars.parentRenderNode;
      } else {
        // root node of an embedded/host view
        return o.NULL_EXPR;
      }
    } else {
      return isPresent(parent.component) &&
          !identical(parent.component.template.encapsulation,
              ViewEncapsulation.Native) ? o.NULL_EXPR : parent.renderNode;
    }
  }

  dynamic visitBoundText(BoundTextAst ast, CompileElement parent) {
    var nodeIndex = this.view.nodes.length;
    this.view.constructorMethod.resetDebugInfo(nodeIndex: nodeIndex);
    var renderNode = this._visitText(ast, "", ast.ngContentIndex, parent);
    return null;
  }

  dynamic visitText(TextAst ast, CompileElement parent) {
    this
        .view
        .constructorMethod
        .resetDebugInfo(nodeIndex: this.view.nodes.length);
    return this._visitText(ast, ast.value, ast.ngContentIndex, parent);
  }

  o.Expression _visitText(TemplateAst ast, String value, num ngContentIndex,
      CompileElement parent) {
    var fieldName = '''_text_${ this . view . nodes . length}''';
    this.view.fields.add(new o.ClassField(
        fieldName,
        o.importType(this.view.genConfig.renderTypes.renderText),
        [o.StmtModifier.Private]));
    var renderNode = o.THIS_EXPR.prop(fieldName);
    var compileNode = new CompileNode(
        parent, this.view, this.view.nodes.length, renderNode, ast);
    var createRenderNode = o.THIS_EXPR
        .prop(fieldName)
        .set(ViewConstructorVars.renderer.callMethod("createText", [
          this._getParentRenderNode(parent),
          o.literal(value),
          this.view.genConfig.genDebugInfo
              ? AllMethodVars.debugContext
              : o.NULL_EXPR
        ]))
        .toStmt();
    this.view.nodes.add(compileNode);
    this.view.constructorMethod.addStmt(createRenderNode);
    this._addRootNodeAndProject(compileNode, ngContentIndex, parent);
    return renderNode;
  }

  dynamic visitNgContent(NgContentAst ast, CompileElement parent) {
    // the projects nodes originate from a different view, so we don't

    // have debug information for them...
    this.view.constructorMethod.resetDebugInfo();
    var parentRenderNode = this._getParentRenderNode(parent);
    var nodesExpression = ViewConstructorVars.projectableNodes.key(
        o.literal(ast.index),
        new o.ArrayType(
            o.importType(this.view.genConfig.renderTypes.renderNode)));
    if (!identical(parentRenderNode, o.NULL_EXPR)) {
      this
          .view
          .constructorMethod
          .addStmt(ViewConstructorVars.renderer.callMethod("projectNodes", [
            parentRenderNode,
            o
                .importExpr(Identifiers.flattenNestedViewRenderNodes)
                .callFn([nodesExpression])
          ]).toStmt());
    } else if (this._isRootNode(parent)) {
      if (!identical(this.view.viewType, ViewType.COMPONENT)) {
        // store root nodes only for embedded/host views
        this.view.rootNodesOrAppElements.add(nodesExpression);
      }
    } else {
      if (isPresent(parent.component) && isPresent(ast.ngContentIndex)) {
        parent.addContentNode(ast.ngContentIndex, nodesExpression);
      }
    }
    return null;
  }

  dynamic visitElement(ElementAst ast, CompileElement parent) {
    var nodeIndex = this.view.nodes.length;
    this.view.constructorMethod.resetDebugInfo(nodeIndex: nodeIndex);
    var createRenderNodeExpr;
    var createElementExpr =
        ViewConstructorVars.renderer.callMethod("createElement", [
      this._getParentRenderNode(parent),
      o.literal(ast.name),
      this.view.genConfig.genDebugInfo
          ? AllMethodVars.debugContext
          : o.NULL_EXPR
    ]);
    if (identical(nodeIndex, 0) &&
        identical(this.view.viewType, ViewType.HOST)) {
      createRenderNodeExpr =
          ViewConstructorVars.rootSelector.identical(o.NULL_EXPR).conditional(
              createElementExpr,
              ViewConstructorVars.renderer.callMethod("selectRootElement", [
                ViewConstructorVars.rootSelector,
                this.view.genConfig.genDebugInfo
                    ? AllMethodVars.debugContext
                    : o.NULL_EXPR
              ]));
    } else {
      createRenderNodeExpr = createElementExpr;
    }
    var fieldName = '''_el_${ nodeIndex}''';
    this.view.fields.add(new o.ClassField(
        fieldName,
        o.importType(this.view.genConfig.renderTypes.renderElement),
        [o.StmtModifier.Private]));
    var createRenderNode =
        o.THIS_EXPR.prop(fieldName).set(createRenderNodeExpr).toStmt();
    var renderNode = o.THIS_EXPR.prop(fieldName);
    var component = ast.getComponent();
    var directives =
        ast.directives.map((directiveAst) => directiveAst.directive).toList();
    var variables = _readHtmlAndDirectiveVariables(
        ast.exportAsVars, ast.directives, this.view.viewType);
    var htmlAttrs = _readHtmlAttrs(ast.attrs);
    var compileElement = new CompileElement(
        parent,
        this.view,
        nodeIndex,
        renderNode,
        ast,
        htmlAttrs,
        directives,
        ast.providers,
        variables,
        component);
    this.view.nodes.add(compileElement);
    this.view.constructorMethod.addStmt(createRenderNode);
    var attrNameAndValues = _mergeHtmlAndDirectiveAttrs(htmlAttrs, directives);
    for (var i = 0; i < attrNameAndValues.length; i++) {
      var attrName = attrNameAndValues[i][0];
      var attrValue = attrNameAndValues[i][1];
      this.view.constructorMethod.addStmt(ViewConstructorVars.renderer
              .callMethod("setElementAttribute", [
            renderNode,
            o.literal(attrName),
            o.literal(attrValue)
          ]).toStmt());
    }
    compileElement.beforeChildren();
    this._addRootNodeAndProject(compileElement, ast.ngContentIndex, parent);
    templateVisitAll(this, ast.children, compileElement);
    compileElement.afterChildren(this.view.nodes.length - nodeIndex - 1);
    if (isPresent(component)) {
      var codeGenContentNodes;
      if (this.view.component.type.isHost) {
        codeGenContentNodes = ViewConstructorVars.projectableNodes;
      } else {
        codeGenContentNodes = o.literalArr(compileElement
            .contentNodesByNgContentIndex
            .map((nodes) => createFlatArray(nodes))
            .toList());
      }
      var nestedComponentIdentifier =
          new CompileIdentifierMetadata(name: getViewFactoryName(component, 0));
      this
          .targetDependencies
          .add(new ViewCompileDependency(component, nestedComponentIdentifier));
      this
          .view
          .constructorMethod
          .addStmt(o.importExpr(nestedComponentIdentifier).callFn([
            ViewConstructorVars.viewManager,
            compileElement.getOrCreateComponentInjector(),
            compileElement.getOrCreateAppElement(),
            codeGenContentNodes,
            o.NULL_EXPR
          ]).toStmt());
    }
    return null;
  }

  dynamic visitEmbeddedTemplate(
      EmbeddedTemplateAst ast, CompileElement parent) {
    var nodeIndex = this.view.nodes.length;
    this.view.constructorMethod.resetDebugInfo(nodeIndex: nodeIndex);
    var fieldName = '''_anchor_${ nodeIndex}''';
    this.view.fields.add(new o.ClassField(
        fieldName,
        o.importType(this.view.genConfig.renderTypes.renderComment),
        [o.StmtModifier.Private]));
    var createRenderNode = o.THIS_EXPR
        .prop(fieldName)
        .set(ViewConstructorVars.renderer.callMethod("createTemplateAnchor", [
          this._getParentRenderNode(parent),
          this.view.genConfig.genDebugInfo
              ? AllMethodVars.debugContext
              : o.NULL_EXPR
        ]))
        .toStmt();
    var renderNode = o.THIS_EXPR.prop(fieldName);
    var templateVariableBindings = ast.vars
        .map((varAst) => [
              varAst.value.length > 0 ? varAst.value : IMPLICIT_TEMPLATE_VAR,
              varAst.name
            ])
        .toList();
    var directives =
        ast.directives.map((directiveAst) => directiveAst.directive).toList();
    var htmlAttrs = _readHtmlAttrs(ast.attrs);
    var compileElement = new CompileElement(parent, this.view, nodeIndex,
        renderNode, ast, htmlAttrs, directives, ast.providers, {}, null);
    this.view.nodes.add(compileElement);
    this.view.constructorMethod.addStmt(createRenderNode);
    this.nestedViewCount++;
    var embeddedView = new CompileView(
        this.view.component,
        this.view.genConfig,
        this.view.pipeMetas,
        o.NULL_EXPR,
        this.view.viewIndex + this.nestedViewCount,
        compileElement,
        templateVariableBindings);
    this.nestedViewCount += buildView(embeddedView, ast.children,
        this.targetDependencies, this.targetStatements);
    compileElement.beforeChildren();
    this._addRootNodeAndProject(compileElement, ast.ngContentIndex, parent);
    compileElement.afterChildren(0);
    return null;
  }

  dynamic visitAttr(AttrAst ast, dynamic ctx) {
    return null;
  }

  dynamic visitDirective(DirectiveAst ast, dynamic ctx) {
    return null;
  }

  dynamic visitEvent(
      BoundEventAst ast, Map<String, BoundEventAst> eventTargetAndNames) {
    return null;
  }

  dynamic visitVariable(VariableAst ast, dynamic ctx) {
    return null;
  }

  dynamic visitDirectiveProperty(
      BoundDirectivePropertyAst ast, dynamic context) {
    return null;
  }

  dynamic visitElementProperty(BoundElementPropertyAst ast, dynamic context) {
    return null;
  }
}

List<List<String>> _mergeHtmlAndDirectiveAttrs(
    Map<String, String> declaredHtmlAttrs,
    List<CompileDirectiveMetadata> directives) {
  Map<String, String> result = {};
  StringMapWrapper.forEach(declaredHtmlAttrs, (value, key) {
    result[key] = value;
  });
  directives.forEach((directiveMeta) {
    StringMapWrapper.forEach(directiveMeta.hostAttributes, (value, name) {
      var prevValue = result[name];
      result[name] = isPresent(prevValue)
          ? mergeAttributeValue(name, prevValue, value)
          : value;
    });
  });
  return mapToKeyValueArray(result);
}

Map<String, String> _readHtmlAttrs(List<AttrAst> attrs) {
  Map<String, String> htmlAttrs = {};
  attrs.forEach((ast) {
    htmlAttrs[ast.name] = ast.value;
  });
  return htmlAttrs;
}

Map<String, CompileTokenMetadata> _readHtmlAndDirectiveVariables(
    List<VariableAst> elementExportAsVars,
    List<DirectiveAst> directives,
    ViewType viewType) {
  Map<String, CompileTokenMetadata> variables = {};
  CompileDirectiveMetadata component = null;
  directives.forEach((directive) {
    if (directive.directive.isComponent) {
      component = directive.directive;
    }
    directive.exportAsVars.forEach((varAst) {
      variables[varAst.name] = identifierToken(directive.directive.type);
    });
  });
  elementExportAsVars.forEach((varAst) {
    variables[varAst.name] =
        isPresent(component) ? identifierToken(component.type) : null;
  });
  if (identical(viewType, ViewType.HOST)) {
    variables[HOST_VIEW_ELEMENT_NAME] = null;
  }
  return variables;
}

String mergeAttributeValue(
    String attrName, String attrValue1, String attrValue2) {
  if (attrName == CLASS_ATTR || attrName == STYLE_ATTR) {
    return '''${ attrValue1} ${ attrValue2}''';
  } else {
    return attrValue2;
  }
}

List<List<String>> mapToKeyValueArray(Map<String, String> data) {
  var entryArray = [];
  StringMapWrapper.forEach(data, (value, name) {
    entryArray.add([name, value]);
  });
  // We need to sort to get a defined output order

  // for tests and for caching generated artifacts...
  ListWrapper.sort(entryArray,
      (entry1, entry2) => StringWrapper.compare(entry1[0], entry2[0]));
  var keyValueArray = [];
  entryArray.forEach((entry) {
    keyValueArray.add([entry[0], entry[1]]);
  });
  return keyValueArray;
}

createViewTopLevelStmts(CompileView view, List<o.Statement> targetStatements) {
  o.Expression nodeDebugInfosVar = o.NULL_EXPR;
  o.Expression bindingDebugInfosVar = o.NULL_EXPR;
  if (view.genConfig.genDebugInfo) {
    nodeDebugInfosVar = o.variable(
        '''nodeDebugInfos_${ view . component . type . name}${ view . viewIndex}''');
    targetStatements.add(((nodeDebugInfosVar as o.ReadVarExpr))
        .set(o.literalArr(
            view.nodes.map(createStaticNodeDebugInfo).toList(),
            new o.ArrayType(new o.ExternalType(Identifiers.StaticNodeDebugInfo),
                [o.TypeModifier.Const])))
        .toDeclStmt(null, [o.StmtModifier.Final]));
    bindingDebugInfosVar = o.variable(
        '''bindingDebugInfos_${ view . component . type . name}${ view . viewIndex}''');
    targetStatements.add(((bindingDebugInfosVar as o.ReadVarExpr))
        .set(o.literalArr(
            view.bindings.map(createStaticBindingDebugInfo).toList(),
            new o.ArrayType(
                new o.ExternalType(Identifiers.StaticBindingDebugInfo),
                [o.TypeModifier.Const])))
        .toDeclStmt(null, [o.StmtModifier.Final]));
  }
  o.ReadVarExpr renderCompTypeVar = null;
  if (identical(view.viewIndex, 0)) {
    renderCompTypeVar =
        o.variable('''renderType_${ view . component . type . name}''');
    targetStatements.add(renderCompTypeVar
        .set(o.NULL_EXPR)
        .toDeclStmt(o.importType(Identifiers.RenderComponentType)));
  }
  var viewClass =
      createViewClass(view, nodeDebugInfosVar, bindingDebugInfosVar);
  targetStatements.add(viewClass);
  targetStatements.add(createViewFactory(view, viewClass, renderCompTypeVar));
}

o.Expression createStaticNodeDebugInfo(CompileNode node) {
  var compileElement = node is CompileElement ? node : null;
  List<o.Expression> providerTokens = [];
  o.Expression componentToken = o.NULL_EXPR;
  var varTokenEntries = [];
  if (isPresent(compileElement)) {
    providerTokens = compileElement.getProviderTokens();
    if (isPresent(compileElement.component)) {
      componentToken = createDiTokenExpression(
          identifierToken(compileElement.component.type));
    }
    StringMapWrapper.forEach(compileElement.variableTokens, (token, varName) {
      varTokenEntries.add([
        varName,
        isPresent(token) ? createDiTokenExpression(token) : o.NULL_EXPR
      ]);
    });
  }
  return o.importExpr(Identifiers.StaticNodeDebugInfo).instantiate(
      [
        o.literal(getTemplateSource(node.sourceAst)),
        o.literalArr(providerTokens,
            new o.ArrayType(o.DYNAMIC_TYPE, [o.TypeModifier.Const])),
        componentToken,
        o.literalMap(varTokenEntries,
            new o.MapType(o.DYNAMIC_TYPE, [o.TypeModifier.Const]))
      ],
      o.importType(
          Identifiers.StaticNodeDebugInfo, null, [o.TypeModifier.Const]));
}

o.Expression createStaticBindingDebugInfo(CompileBinding binding) {
  return o.importExpr(Identifiers.StaticBindingDebugInfo).instantiate(
      [o.literal(getTemplateSource(binding.sourceAst))],
      o.importType(
          Identifiers.StaticBindingDebugInfo, null, [o.TypeModifier.Const]));
}

o.ClassStmt createViewClass(CompileView view, o.Expression nodeDebugInfosVar,
    o.Expression bindingDebugInfosVar) {
  o.Expression parentRenderNodeExpr = o.NULL_EXPR;
  var parentRenderNodeStmts = [];
  if (identical(view.viewType, ViewType.COMPONENT)) {
    parentRenderNodeExpr = ViewConstructorVars.renderer.callMethod(
        "createViewRoot",
        [ViewConstructorVars.declarationEl.prop("nativeElement")]);
    parentRenderNodeStmts = [
      ViewConstructorVars.parentRenderNode.set(parentRenderNodeExpr).toDeclStmt(
          o.importType(view.genConfig.renderTypes.renderNode),
          [o.StmtModifier.Final])
    ];
  }
  view.constructorMethod.addStmt(o.THIS_EXPR.callMethod("init", [
    createFlatArray(view.rootNodesOrAppElements),
    o.literalArr(view.nodes.map((node) => node.renderNode).toList()),
    o.literalMap(view.namedAppElements),
    o.literalArr(view.disposables),
    o.literalArr(view.subscriptions),
    o.literal(false)
  ]).toStmt());
  view.constructorMethod.addDebugErrorStmt(o.THIS_EXPR.callMethod("init", [
    createFlatArray(view.rootNodesOrAppElements),
    o.literalArr(view.nodes.map((node) => node.renderNode).toList()),
    o.literalMap(view.namedAppElements),
    o.literalArr([]),
    o.literalArr([]),
    o.literal(true)
  ]).toStmt());
  var emptyTemplateVariableBindings = view.templateVariableBindings
      .map((entry) => [entry[0], o.NULL_EXPR])
      .toList();
  var viewConstructorArgs = [
    new o.FnParam(ViewConstructorVars.viewManager.name,
        o.importType(Identifiers.AppViewManager_)),
    new o.FnParam(ViewConstructorVars.renderer.name,
        o.importType(view.genConfig.renderTypes.renderer)),
    new o.FnParam(ViewConstructorVars.parentInjector.name,
        o.importType(Identifiers.Injector)),
    new o.FnParam(ViewConstructorVars.declarationEl.name,
        o.importType(Identifiers.AppElement)),
    new o.FnParam(
        ViewConstructorVars.projectableNodes.name,
        new o.ArrayType(new o.ArrayType(
            o.importType(view.genConfig.renderTypes.renderNode)))),
    new o.FnParam(ViewConstructorVars.rootSelector.name, o.STRING_TYPE)
  ];
  var viewConstructorBody = (new List.from((new List.from([
    o.SUPER_EXPR.callFn([
      o.variable(view.className),
      ViewTypeEnum.fromValue(view.viewType),
      o.literalMap(emptyTemplateVariableBindings),
      ViewConstructorVars.renderer,
      ViewConstructorVars.viewManager,
      ViewConstructorVars.parentInjector,
      ViewConstructorVars.projectableNodes,
      ViewConstructorVars.declarationEl,
      ChangeDetectionStrategyEnum.fromValue(view.component.changeDetection),
      nodeDebugInfosVar,
      bindingDebugInfosVar
    ]).toStmt()
  ])..addAll(parentRenderNodeStmts)))..addAll(view.constructorMethod.finish()));
  var viewConstructor =
      new o.ClassMethod(null, viewConstructorArgs, viewConstructorBody);
  var viewMethods = (new List.from([
    new o.ClassMethod(
        "injectorGet",
        [
          new o.FnParam(InjectMethodVars.token.name, o.DYNAMIC_TYPE),
          // Note: Can't use o.INT_TYPE here as the method in AppView uses number
          new o.FnParam(InjectMethodVars.requestNodeIndex.name, o.NUMBER_TYPE),
          new o.FnParam(InjectMethodVars.notFoundResult.name, o.DYNAMIC_TYPE)
        ],
        addReturnValuefNotEmpty(
            view.injectorGetMethod.finish(), InjectMethodVars.notFoundResult),
        o.DYNAMIC_TYPE),
    new o.ClassMethod(
        "injectorPrivateGet",
        [
          new o.FnParam(InjectMethodVars.token.name, o.DYNAMIC_TYPE),
          // Note: Can't use o.INT_TYPE here as the method in AppView uses number
          new o.FnParam(InjectMethodVars.requestNodeIndex.name, o.NUMBER_TYPE),
          new o.FnParam(InjectMethodVars.notFoundResult.name, o.DYNAMIC_TYPE)
        ],
        addReturnValuefNotEmpty(view.injectorPrivateGetMethod.finish(),
            InjectMethodVars.notFoundResult),
        o.DYNAMIC_TYPE),
    new o.ClassMethod("updateContentQueriesInternal", [],
        view.updateContentQueriesMethod.finish()),
    new o.ClassMethod(
        "updateViewQueriesInternal", [], view.updateViewQueriesMethod.finish()),
    new o.ClassMethod("dirtyParentQueriesInternal", [],
        view.dirtyParentQueriesMethod.finish()),
    new o.ClassMethod("detectChangesInInputsInternal", [],
        addDetectChangesVars(view.detectChangesInInputsMethod.finish())),
    new o.ClassMethod("detectChangesHostPropertiesInternal", [],
        addDetectChangesVars(view.detectChangesHostPropertiesMethod.finish())),
    new o.ClassMethod("afterContentLifecycleCallbacksInternal", [],
        view.afterContentLifecycleCallbacksMethod.finish()),
    new o.ClassMethod("afterViewLifecycleCallbacksInternal", [],
        view.afterViewLifecycleCallbacksMethod.finish()),
    new o.ClassMethod("destroyInternal", [], view.destroyMethod.finish())
  ])..addAll(view.eventHandlerMethods));
  if (view.genConfig.genDebugInfo) {
    viewMethods.add(new o.ClassMethod(
        "checkNoChangesInternal", [], view.checkNoChangesMethod.finish()));
  }
  var viewClass = new o.ClassStmt(
      view.className,
      o.importExpr(Identifiers.AppView, [getContextType(view)]),
      view.fields,
      view.getters,
      viewConstructor,
      viewMethods.where((method) => method.body.length > 0).toList());
  return viewClass;
}

o.Statement createViewFactory(
    CompileView view, o.ClassStmt viewClass, o.ReadVarExpr renderCompTypeVar) {
  var viewFactoryArgs = [
    new o.FnParam(ViewConstructorVars.viewManager.name,
        o.importType(Identifiers.AppViewManager_)),
    new o.FnParam(ViewConstructorVars.parentInjector.name,
        o.importType(Identifiers.Injector)),
    new o.FnParam(ViewConstructorVars.declarationEl.name,
        o.importType(Identifiers.AppElement)),
    new o.FnParam(
        ViewConstructorVars.projectableNodes.name,
        new o.ArrayType(new o.ArrayType(
            o.importType(view.genConfig.renderTypes.renderNode)))),
    new o.FnParam(ViewConstructorVars.rootSelector.name, o.STRING_TYPE)
  ];
  o.Expression rendererExpr;
  var initRenderCompTypeStmts = [];
  if (isPresent(renderCompTypeVar)) {
    initRenderCompTypeStmts = [
      new o.IfStmt(renderCompTypeVar.identical(o.NULL_EXPR), [
        renderCompTypeVar
            .set(ViewConstructorVars.viewManager
                .callMethod("createRenderComponentType", [
              ViewEncapsulationEnum
                  .fromValue(view.component.template.encapsulation),
              view.styles
            ]))
            .toStmt()
      ])
    ];
    rendererExpr = ViewConstructorVars.viewManager
        .callMethod("renderComponent", [renderCompTypeVar]);
  } else {
    rendererExpr =
        ViewConstructorVars.declarationEl.prop("parentView").prop("renderer");
  }
  return o
      .fn(
          viewFactoryArgs,
          (new List.from(initRenderCompTypeStmts)
            ..addAll([
              ViewConstructorVars.projectableNodes
                  .set(o.importExpr(Identifiers.ensureSlotCount).callFn([
                    ViewConstructorVars.projectableNodes,
                    o.literal(view.component.template.ngContentSelectors.length)
                  ]))
                  .toStmt(),
              ViewConstructorVars.renderer.set(rendererExpr).toDeclStmt(
                  o.importType(view.genConfig.renderTypes.renderer),
                  [o.StmtModifier.Final]),
              new o.ReturnStatement(o.variable(viewClass.name).instantiate(
                  viewClass.constructorMethod.params
                      .map((param) => o.variable(param.name))
                      .toList()))
            ])),
          o.importType(Identifiers.AppView, [getContextType(view)]))
      .toDeclStmt(view.viewFactory.name, [o.StmtModifier.Final]);
}

List<o.Statement> addDetectChangesVars(List<o.Statement> statements) {
  var varStmts = [];
  var readVars = o.findReadVarNames(statements);
  if (SetWrapper.has(readVars, DetectChangesVars.changed.name)) {
    varStmts.add(
        DetectChangesVars.changed.set(o.literal(true)).toDeclStmt(o.BOOL_TYPE));
  }
  if (SetWrapper.has(readVars, DetectChangesVars.changes.name)) {
    varStmts.add(DetectChangesVars.changes.set(o.NULL_EXPR).toDeclStmt());
  }
  return (new List.from(varStmts)..addAll(statements));
}

List<o.Statement> addReturnValuefNotEmpty(
    List<o.Statement> statements, o.Expression value) {
  if (statements.length > 0) {
    return (new List.from(statements)..addAll([new o.ReturnStatement(value)]));
  } else {
    return statements;
  }
}

o.Type getContextType(CompileView view) {
  var typeMeta = view.component.type;
  return typeMeta.isHost ? o.DYNAMIC_TYPE : o.importType(typeMeta);
}
