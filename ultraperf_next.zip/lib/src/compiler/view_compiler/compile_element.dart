library angular2.src.compiler.view_compiler.compile_element;

import "../output/output_ast.dart" as o;
import "constants.dart" show Identifiers, InjectMethodVars;
import "compile_view.dart" show CompileView, CompileError;
import "package:angular2/src/facade/lang.dart" show isPresent, isBlank;
import "package:angular2/src/facade/collection.dart"
    show ListWrapper, StringMapWrapper;
import "package:angular2/src/facade/exceptions.dart" show BaseException;
import "../template_ast.dart" show TemplateAst, ProviderAst, ProviderAstType;
import "../compile_metadata.dart"
    show
        CompileTokenMap,
        CompileDirectiveMetadata,
        CompileTokenMetadata,
        CompileQueryMetadata,
        CompileProviderMetadata,
        CompileDiDependencyMetadata,
        CompileIdentifierMetadata,
        CompileTypeMetadata;
import "util.dart"
    show
        getPropertyInView,
        createDiTokenExpression,
        injectFromViewParentInjector,
        identifierToken,
        getTemplateSource;
import "compile_query.dart" show CompileQuery, createQueryList;
import "compile_method.dart" show CompileMethod;
import "../template_parser.dart" show normalizeProviders;

class CompileNode {
  CompileElement parent;
  CompileView view;
  num nodeIndex;
  o.Expression renderNode;
  TemplateAst sourceAst;
  CompileNode(this.parent, this.view, this.nodeIndex, this.renderNode,
      this.sourceAst) {}
  bool isNull() {
    return isBlank(this.renderNode);
  }

  bool isRootElement() {
    return this.view != this.parent.view;
  }
}

class CompileElement extends CompileNode {
  Map<String, String> attrNameAndValues;
  List<CompileDirectiveMetadata> _directives;
  List<ProviderAst> _resolvedProviders;
  Map<String, CompileTokenMetadata> variableTokens;
  CompileDirectiveMetadata component;
  static CompileElement createNull() {
    return new CompileElement(
        null, null, null, null, null, {}, [], [], {}, null);
  }

  o.Expression _appElement;
  o.Expression _defaultInjector;
  o.Expression _componentInjector;
  var _instances = new CompileTokenMap<o.Expression>();
  var _instancesToBeCreated = new CompileTokenMap<bool>();
  var _providerByToken = new CompileTokenMap<ProviderAst>();
  List<CompileQuery> _queries = [];
  List<o.Expression> _componentConstructorViewQueryLists = [];
  List<List<o.Expression>> contentNodesByNgContentIndex;
  CompileView embeddedView;
  List<o.Expression> directiveInstances;
  CompileElement(
      CompileElement parent,
      CompileView view,
      num nodeIndex,
      o.Expression renderNode,
      TemplateAst sourceAst,
      this.attrNameAndValues,
      this._directives,
      this._resolvedProviders,
      this.variableTokens,
      this.component)
      : super(parent, view, nodeIndex, renderNode, sourceAst) {
    /* super call moved to initializer */;
    if (isPresent(component)) {
      this.contentNodesByNgContentIndex = ListWrapper
          .createFixedSize(component.template.ngContentSelectors.length);
      for (var i = 0; i < this.contentNodesByNgContentIndex.length; i++) {
        this.contentNodesByNgContentIndex[i] = [];
      }
    } else {
      this.contentNodesByNgContentIndex = null;
    }
  }
  List<CompileQuery> _getQueriesFor(CompileTokenMetadata token) {
    var result = [];
    CompileElement currentEl = this;
    var distance = 0;
    while (!currentEl.isNull()) {
      currentEl._queries.forEach((query) {
        query.meta.selectors.forEach((selector) {
          if (selector.equalsTo(token) &&
              (query.meta.descendants || distance <= 1)) {
            result.add(query);
          }
        });
      });
      currentEl = currentEl.parent;
      distance++;
    }
    this.view.componentView.viewQueries.forEach((query) {
      query.meta.selectors.forEach((selector) {
        if (selector.equalsTo(token)) {
          result.add(query);
        }
      });
    });
    return result;
  }

  CompileQuery _addQuery(
      CompileQueryMetadata queryMeta, o.Expression directiveInstance) {
    var propName =
        '''_query_${ queryMeta . selectors [ 0 ] . name}_${ this . nodeIndex}_${ this . _queries . length}''';
    var queryList =
        createQueryList(queryMeta, directiveInstance, propName, this.view);
    var query =
        new CompileQuery(queryMeta, queryList, directiveInstance, this.view);
    this._queries.add(query);
    return query;
  }

  setEmbeddedView(CompileView embeddedView) {
    this.embeddedView = embeddedView;
    if (isPresent(embeddedView)) {
      var createTemplateRefExpr = o
          .importExpr(Identifiers.TemplateRef_)
          .instantiate(
              [this.getOrCreateAppElement(), this.embeddedView.viewFactory]);
      var provider = new CompileProviderMetadata(
          token: identifierToken(Identifiers.TemplateRef),
          useValue: createTemplateRefExpr);
      this._resolvedProviders.add(new ProviderAst(provider.token, false,
          [provider], ProviderAstType.Builtin, this.sourceAst.sourceSpan));
    }
  }

  beforeChildren() {
    this._resolvedProviders.forEach((resolvedProvider) {
      this._providerByToken.add(resolvedProvider.token, resolvedProvider);
    });
    this.directiveInstances = this
        ._directives
        .map((directive) => this._getOrCreateLocalProvider(
            ProviderAstType.Directive, identifierToken(directive.type), true))
        .toList();
    for (var i = 0; i < this.directiveInstances.length; i++) {
      var directiveInstance = this.directiveInstances[i];
      var directive = this._directives[i];
      directive.queries.forEach((queryMeta) {
        this._addQuery(queryMeta, directiveInstance);
      });
    }
    this._resolvedProviders.forEach((resolvedProvider) {
      var queriesForProvider = this._getQueriesFor(resolvedProvider.token);
      if (queriesForProvider.length > 0) {
        var providerExpr = this._instances.get(resolvedProvider.token);
        if (isBlank(providerExpr)) {
          providerExpr = this._getOrCreateLocalProvider(
              resolvedProvider.providerType, resolvedProvider.token, true);
        }
        queriesForProvider.forEach((query) {
          query.addValue(providerExpr, this.view);
        });
      }
    });
    StringMapWrapper.forEach(this.variableTokens, (_, varName) {
      var token = this.variableTokens[varName];
      var varValue;
      var varValueForQuery;
      if (isPresent(token)) {
        varValue = varValueForQuery = this._instances.get(token);
      } else {
        varValueForQuery = this.getOrCreateAppElement().prop("ref");
        varValue = this.renderNode;
      }
      this.view.variables[varName] = varValue;
      this.view.namedAppElements.add([varName, this.getOrCreateAppElement()]);
      var queriesForProvider =
          this._getQueriesFor(new CompileTokenMetadata(value: varName));
      queriesForProvider.forEach((query) {
        query.addValue(varValueForQuery, this.view);
      });
    });
    if (isPresent(this.component)) {
      var componentConstructorViewQueryList = isPresent(this.component)
          ? o.literalArr(this._componentConstructorViewQueryLists)
          : o.NULL_EXPR;
      var compExpr =
          isPresent(this.getComponent()) ? this.getComponent() : o.NULL_EXPR;
      this.view.constructorMethod.addStmt(this
          .getOrCreateAppElement()
          .callMethod("initComponent",
              [compExpr, componentConstructorViewQueryList]).toStmt());
    }
  }

  afterChildren(num childNodeCount) {
    this._resolvedProviders.forEach((resolvedProvider) {
      var providerExpr = this._instances.get(resolvedProvider.token);
      if (isBlank(providerExpr)) {
        // Create all non instantiated providers as lazy providers
        providerExpr = this._getOrCreateLocalProvider(
            resolvedProvider.providerType, resolvedProvider.token, false);
      }
      // Note: afterChildren is called after recursing into children.

      // This is good so that an injector match in an element that is closer to a requesting element

      // matches first.
      if (!identical(
          resolvedProvider.providerType, ProviderAstType.PrivateService)) {
        this.view.injectorGetMethod.addStmt(createInjectInternalCondition(
            this.nodeIndex, childNodeCount, resolvedProvider, providerExpr));
      }
      if (identical(
              resolvedProvider.providerType, ProviderAstType.PrivateService) ||
          identical(resolvedProvider.providerType, ProviderAstType.Component)) {
        this.view.injectorPrivateGetMethod.addStmt(
            createInjectInternalCondition(
                this.nodeIndex, 0, resolvedProvider, providerExpr));
      }
    });
    this._queries.forEach((query) {
      query.afterChildren(this.view.updateContentQueriesMethod);
    });
  }

  addContentNode(num ngContentIndex, o.Expression nodeExpr) {
    this.contentNodesByNgContentIndex[ngContentIndex].add(nodeExpr);
  }

  o.Expression getComponent() {
    return isPresent(this.component)
        ? this._instances.get(identifierToken(this.component.type))
        : null;
  }

  List<o.Expression> getProviderTokens() {
    return this
        ._resolvedProviders
        .map((resolvedProvider) =>
            createDiTokenExpression(resolvedProvider.token))
        .toList();
  }

  List<String> getDeclaredVariablesNames() {
    var res = [];
    StringMapWrapper.forEach(this.variableTokens, (_, key) {
      res.add(key);
    });
    return res;
  }

  o.Expression getOptionalAppElement() {
    return this._appElement;
  }

  o.Expression getOrCreateAppElement() {
    if (isBlank(this._appElement)) {
      var parentNodeIndex = this.isRootElement() ? null : this.parent.nodeIndex;
      var fieldName = '''_appEl_${ this . nodeIndex}''';
      this.view.fields.add(new o.ClassField(fieldName,
          o.importType(Identifiers.AppElement), [o.StmtModifier.Private]));
      var statement = o.THIS_EXPR
          .prop(fieldName)
          .set(o.importExpr(Identifiers.AppElement).instantiate([
            o.literal(this.nodeIndex),
            o.literal(parentNodeIndex),
            o.THIS_EXPR,
            this.renderNode
          ]))
          .toStmt();
      this.view.constructorMethod.addStmt(statement);
      this._appElement = o.THIS_EXPR.prop(fieldName);
    }
    return this._appElement;
  }

  o.Expression getOrCreateComponentInjector() {
    if (isBlank(this._componentInjector)) {
      var fieldName = '''_compInj_${ this . nodeIndex}''';
      this.view.fields.add(new o.ClassField(fieldName,
          o.importType(Identifiers.Injector), [o.StmtModifier.Private]));
      var statement =
          o.THIS_EXPR.prop(fieldName).set(this._createInjector(true)).toStmt();
      this.view.constructorMethod.addStmt(statement);
      this._componentInjector = o.THIS_EXPR.prop(fieldName);
    }
    return this._componentInjector;
  }

  o.Expression getOrCreateDefaultInjector() {
    if (isBlank(this._defaultInjector)) {
      var fieldName = '''_inj_${ this . nodeIndex}''';
      this.view.fields.add(new o.ClassField(fieldName,
          o.importType(Identifiers.Injector), [o.StmtModifier.Private]));
      var statement =
          o.THIS_EXPR.prop(fieldName).set(this._createInjector(false)).toStmt();
      this.view.constructorMethod.addStmt(statement);
      this._defaultInjector = o.THIS_EXPR.prop(fieldName);
    }
    return this._defaultInjector;
  }

  o.Expression _createInjector(bool readPrivate) {
    return o.THIS_EXPR.callMethod(
        "injector", [o.literal(this.nodeIndex), o.literal(readPrivate)]);
  }

  o.Expression _getOrCreateLocalProvider(ProviderAstType requestingProviderType,
      CompileTokenMetadata token, bool eager) {
    var resolvedProvider = this._providerByToken.get(token);
    if (isBlank(resolvedProvider) ||
        ((identical(requestingProviderType, ProviderAstType.Directive) ||
                identical(
                    requestingProviderType, ProviderAstType.PublicService)) &&
            identical(resolvedProvider.providerType,
                ProviderAstType.PrivateService)) ||
        ((identical(requestingProviderType, ProviderAstType.PrivateService) ||
                identical(
                    requestingProviderType, ProviderAstType.PublicService)) &&
            identical(
                resolvedProvider.providerType, ProviderAstType.Builtin))) {
      return null;
    }
    var instance = this._instances.get(token);
    if (isPresent(instance)) {
      return instance;
    }
    if (isPresent(this._instancesToBeCreated.get(token))) {
      this.view.addError(new CompileError(
          '''Cannot instantiate cyclic dependency! ${ token . name}''',
          this.sourceAst));
      return o.NULL_EXPR;
    }
    this._instancesToBeCreated.add(token, true);
    var providerValueExpressions = resolvedProvider.providers.map((provider) {
      if (isPresent(provider.useExisting)) {
        return this._getDependency(
            resolvedProvider.providerType,
            new CompileDiDependencyMetadata(token: provider.useExisting),
            eager);
      } else if (isPresent(provider.useFactory)) {
        var deps = isPresent(provider.deps)
            ? provider.deps
            : provider.useFactory.diDeps;
        var depsExpr = deps
            .map((dep) =>
                this._getDependency(resolvedProvider.providerType, dep, eager))
            .toList();
        return o.importExpr(provider.useFactory).callFn(depsExpr);
      } else if (isPresent(provider.useClass)) {
        var deps =
            isPresent(provider.deps) ? provider.deps : provider.useClass.diDeps;
        var depsExpr = deps
            .map((dep) =>
                this._getDependency(resolvedProvider.providerType, dep, eager))
            .toList();
        return o
            .importExpr(provider.useClass)
            .instantiate(depsExpr, o.importType(provider.useClass));
      } else {
        if (provider.useValue is CompileIdentifierMetadata) {
          return o.importExpr(provider.useValue);
        } else if (provider.useValue is o.Expression) {
          return provider.useValue;
        } else {
          return o.literal(provider.useValue);
        }
      }
    }).toList();
    var propName =
        '''_${ resolvedProvider . token . name}_${ this . nodeIndex}_${ this . _instances . size}''';
    instance = createProviderProperty(propName, resolvedProvider,
        providerValueExpressions, resolvedProvider.multiProvider, eager, this);
    this._instances.add(token, instance);
    return instance;
  }

  o.Expression _getLocalDependency(
      ProviderAstType requestingProviderType, CompileDiDependencyMetadata dep,
      [bool eager = null]) {
    var result = null;
    if (dep.isSkipSelf) {
      return null;
    }
    // constructor content query
    if (isBlank(result) && isPresent(dep.query)) {
      result = this._addQuery(dep.query, null).queryList;
    }
    // constructor view query
    if (isBlank(result) && isPresent(dep.viewQuery)) {
      result = createQueryList(
          dep.viewQuery,
          null,
          '''_viewQuery_${ dep . viewQuery . selectors [ 0 ] . name}_${ this . nodeIndex}_${ this . _componentConstructorViewQueryLists . length}''',
          this.view);
      this._componentConstructorViewQueryLists.add(result);
    }
    if (isPresent(dep.token)) {
      // access attributes
      if (dep.isAttribute) {
        var attrValue = this.attrNameAndValues[dep.token.value];
        result = isPresent(attrValue) ? o.literal(attrValue) : o.NULL_EXPR;
      }
      // access builtints
      if (isBlank(result) &&
          (identical(requestingProviderType, ProviderAstType.Directive) ||
              identical(requestingProviderType, ProviderAstType.Component))) {
        if (dep.token.equalsTo(identifierToken(Identifiers.Renderer))) {
          result = o.THIS_EXPR.prop("renderer");
        } else if (dep.token
            .equalsTo(identifierToken(Identifiers.ElementRef))) {
          result = this.getOrCreateAppElement().prop("ref");
        } else if (dep.token
            .equalsTo(identifierToken(Identifiers.ChangeDetectorRef))) {
          if (identical(requestingProviderType, ProviderAstType.Directive) ||
              isBlank(this.component)) {
            return o.THIS_EXPR.prop("ref");
          } else {
            return this
                .getOrCreateAppElement()
                .prop("componentChangeDetectorRef");
          }
        } else if (dep.token
            .equalsTo(identifierToken(Identifiers.ViewContainerRef))) {
          result = this.getOrCreateAppElement().prop("vcRef");
        }
      }
      // access providers
      if (isBlank(result)) {
        result = this._getOrCreateLocalProvider(
            requestingProviderType, dep.token, eager);
      }
      // access the injector
      if (isBlank(result) &&
          dep.token.equalsTo(identifierToken(Identifiers.Injector))) {
        if (identical(requestingProviderType, ProviderAstType.Component) ||
            identical(requestingProviderType, ProviderAstType.PrivateService)) {
          result = this.getOrCreateComponentInjector();
        } else {
          result = this.getOrCreateDefaultInjector();
        }
      }
    }
    // check @Self restriction
    if (isBlank(result) && dep.isSelf) {
      result = o.NULL_EXPR;
    }
    return result;
  }

  o.Expression _getDependency(
      ProviderAstType requestingProviderType, CompileDiDependencyMetadata dep,
      [bool eager = null]) {
    CompileElement currElement = this;
    var currView = currElement.view;
    bool currEager = eager;
    var result = this._getLocalDependency(requestingProviderType, dep, eager);
    var resultViewPath = [];
    // check parent elements
    while (isBlank(result) && !currElement.parent.isNull()) {
      currElement = currElement.parent;
      while (!identical(currElement.view, currView) && currView != null) {
        currEager = false;
        resultViewPath.add(currView);
        currView = currView.declarationElement.view;
      }
      result = currElement._getLocalDependency(ProviderAstType.PublicService,
          new CompileDiDependencyMetadata(token: dep.token), currEager);
    }
    // check parent components

    // check @Host restriction
    if (isBlank(result)) {
      var comp = this.view.component;
      if (dep.isHost && !comp.type.isHost) {
        var isProvided = identifierToken(comp.type).equalsTo(dep.token) ||
            normalizeProviders(comp.viewProviders)
                .any((provider) => provider.token.equalsTo(dep.token));
        result = isProvided
            ? injectFromViewParentInjector(dep.token, dep.isOptional)
            : o.NULL_EXPR;
      } else {
        result = injectFromViewParentInjector(dep.token, dep.isOptional);
      }
    }
    if (isBlank(result) ||
        (identical(result, o.NULL_EXPR) &&
            !dep.isOptional &&
            !dep.isAttribute)) {
      this.view.addError(new CompileError(
          '''No provider for ${ dep . token . name}''', this.sourceAst));
      result = o.NULL_EXPR;
    }
    return getPropertyInView(result, resultViewPath);
  }
}

o.Statement createInjectInternalCondition(num nodeIndex, num childNodeCount,
    ProviderAst provider, o.Expression providerExpr) {
  var indexCondition;
  if (childNodeCount > 0) {
    indexCondition = o
        .literal(nodeIndex)
        .lowerEquals(InjectMethodVars.requestNodeIndex)
        .and(InjectMethodVars.requestNodeIndex
            .lowerEquals(o.literal(nodeIndex + childNodeCount)));
  } else {
    indexCondition =
        o.literal(nodeIndex).identical(InjectMethodVars.requestNodeIndex);
  }
  return new o.IfStmt(
      InjectMethodVars.token
          .identical(createDiTokenExpression(provider.token))
          .and(indexCondition),
      [new o.ReturnStatement(providerExpr)]);
}

o.Expression createProviderProperty(
    String propName,
    ProviderAst provider,
    List<o.Expression> providerValueExpressions,
    bool isMulti,
    bool isEager,
    CompileElement compileElement) {
  var view = compileElement.view;
  var resolvedProviderValueExpr;
  var type;
  if (isMulti) {
    resolvedProviderValueExpr = o.literalArr(providerValueExpressions);
    type = new o.ArrayType(o.DYNAMIC_TYPE);
  } else {
    resolvedProviderValueExpr = providerValueExpressions[0];
    type = providerValueExpressions[0].type;
  }
  if (isBlank(type)) {
    type = o.DYNAMIC_TYPE;
  }
  if (isEager) {
    view.fields.add(new o.ClassField(propName, type, [o.StmtModifier.Private]));
    view.constructorMethod.addStmt(
        o.THIS_EXPR.prop(propName).set(resolvedProviderValueExpr).toStmt());
  } else {
    var internalField = '''_${ propName}''';
    view.fields
        .add(new o.ClassField(internalField, type, [o.StmtModifier.Private]));
    var getter =
        new CompileMethod(view, '''lazy create ${ provider . token . name}''');
    getter.resetDebugInfo(nodeIndex: compileElement.nodeIndex);
    // Note: Equals is important for JS so that it also checks the undefined case!
    getter.addStmt(new o.IfStmt(o.THIS_EXPR.prop(internalField).isBlank(), [
      o.THIS_EXPR.prop(internalField).set(resolvedProviderValueExpr).toStmt()
    ]));
    getter.addStmt(new o.ReturnStatement(o.THIS_EXPR.prop(internalField)));
    view.getters.add(new o.ClassGetter(propName, getter.finish(), type));
  }
  return o.THIS_EXPR.prop(propName);
}
