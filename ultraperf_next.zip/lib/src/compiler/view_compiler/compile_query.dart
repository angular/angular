library angular2.src.compiler.view_compiler.compile_query;

import "package:angular2/src/facade/lang.dart" show isPresent;
import "package:angular2/src/facade/collection.dart" show ListWrapper;
import "../output/output_ast.dart" as o;
import "constants.dart" show Identifiers;
import "../compile_metadata.dart"
    show CompileQueryMetadata, CompileIdentifierMetadata;
import "compile_view.dart" show CompileView;
import "compile_element.dart" show CompileElement;
import "compile_method.dart" show CompileMethod;
import "util.dart" show getPropertyInView;

class ViewQueryValues {
  CompileView view;
  List<dynamic /* o . Expression | ViewQueryValues */ > values;
  ViewQueryValues(this.view, this.values) {}
}

class CompileQuery {
  CompileQueryMetadata meta;
  o.Expression queryList;
  o.Expression ownerDirectiveExpression;
  CompileView view;
  ViewQueryValues _values;
  CompileQuery(
      this.meta, this.queryList, this.ownerDirectiveExpression, this.view) {
    this._values = new ViewQueryValues(view, []);
  }
  addValue(o.Expression value, CompileView view) {
    var currentView = view;
    List<CompileElement> elPath = [];
    List<CompileView> viewPath = [];
    while (isPresent(currentView) && !identical(currentView, this.view)) {
      var parentEl = currentView.declarationElement;
      (elPath..insert(0, parentEl)).length;
      currentView = parentEl.view;
      viewPath.add(currentView);
    }
    var queryListForDirtyExpr = getPropertyInView(this.queryList, viewPath);
    var viewValues = this._values;
    elPath.forEach((el) {
      var last = viewValues.values.length > 0
          ? viewValues.values[viewValues.values.length - 1]
          : null;
      if (last is ViewQueryValues && identical(last.view, el.embeddedView)) {
        viewValues = last;
      } else {
        var newViewValues = new ViewQueryValues(el.embeddedView, []);
        viewValues.values.add(newViewValues);
        viewValues = newViewValues;
      }
    });
    viewValues.values.add(value);
    if (elPath.length > 0) {
      view.dirtyParentQueriesMethod
          .addStmt(queryListForDirtyExpr.callMethod("setDirty", []).toStmt());
    }
  }

  afterChildren(CompileMethod targetMethod) {
    var values = createQueryValues(this._values);
    var notifyChangesStmt;
    if (this.meta.first && isPresent(this.ownerDirectiveExpression)) {
      notifyChangesStmt = this
          .ownerDirectiveExpression
          .prop(this.meta.propertyName)
          .set(this.queryList.prop("first"))
          .toStmt();
    } else {
      notifyChangesStmt =
          this.queryList.callMethod("notifyOnChanges", []).toStmt();
    }
    targetMethod.addStmt(new o.IfStmt(this.queryList.prop("dirty"), [
      this.queryList.callMethod("reset", [o.literalArr(values)]).toStmt(),
      notifyChangesStmt
    ]));
  }
}

List<o.Expression> createQueryValues(ViewQueryValues viewValues) {
  return ListWrapper.flatten(viewValues.values.map((entry) {
    if (entry is ViewQueryValues) {
      return mapNestedViews(
          entry.view.declarationElement.getOrCreateAppElement(),
          entry.view,
          createQueryValues(entry));
    } else {
      return (entry as o.Expression);
    }
  }).toList());
}

o.Expression mapNestedViews(o.Expression declarationAppElement,
    CompileView view, List<o.Expression> expressions) {
  List<o.Expression> adjustedExpressions = expressions.map((expr) {
    return o.replaceVarInExpression(
        o.THIS_EXPR.name, o.variable("nestedView"), expr);
  }).toList();
  return declarationAppElement.callMethod("mapNestedViews", [
    o.variable(view.className),
    o.fn([new o.FnParam("nestedView", view.classType)],
        [new o.ReturnStatement(o.literalArr(adjustedExpressions))])
  ]);
}

o.Expression createQueryList(
    CompileQueryMetadata query,
    o.Expression directiveInstance,
    String propertyName,
    CompileView compileView) {
  compileView.fields.add(new o.ClassField(propertyName,
      o.importType(Identifiers.QueryList), [o.StmtModifier.Private]));
  var expr = o.THIS_EXPR.prop(propertyName);
  compileView.constructorMethod.addStmt(o.THIS_EXPR
      .prop(propertyName)
      .set(o.importExpr(Identifiers.QueryList).instantiate([]))
      .toStmt());
  if (!query.first && isPresent(directiveInstance)) {
    compileView.constructorMethod
        .addStmt(directiveInstance.prop(query.propertyName).set(expr).toStmt());
  }
  return expr;
}
