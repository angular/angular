// Public API for render
library angular2.src.core.render;

export "render/api.dart" show RootRenderer, Renderer, RenderComponentType;
