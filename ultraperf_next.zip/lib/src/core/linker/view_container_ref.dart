library angular2.src.core.linker.view_container_ref;

import "package:angular2/src/facade/collection.dart" show ListWrapper;
import "package:angular2/src/facade/exceptions.dart" show unimplemented;
import "package:angular2/src/core/di/injector.dart"
    show Injector, Injector_, ProtoInjector;
import "package:angular2/src/core/di/provider.dart" show ResolvedProvider;
import "package:angular2/src/facade/lang.dart" show isPresent, isBlank;
import "../profile/profile.dart" show wtfCreateScope, wtfLeave, WtfScopeFn;
import "element.dart" show AppElement;
import "element_ref.dart" show ElementRef, ElementRef_;
import "template_ref.dart" show TemplateRef, TemplateRef_;
import "view_ref.dart"
    show
        EmbeddedViewRef,
        HostViewRef,
        HostViewFactoryRef,
        HostViewFactoryRef_,
        ViewRef,
        ViewRef_;
import "view.dart" show AppView;

/**
 * Represents a container where one or more Views can be attached.
 *
 * The container can contain two kinds of Views. Host Views, created by instantiating a
 * [Component] via [#createHostView], and Embedded Views, created by instantiating an
 * [TemplateRef Embedded Template] via [#createEmbeddedView].
 *
 * The location of the View Container within the containing View is specified by the Anchor
 * `element`. Each View Container can have only one Anchor Element and each Anchor Element can only
 * have a single View Container.
 *
 * Root elements of Views attached to this container become siblings of the Anchor Element in
 * the Rendered View.
 *
 * To access a `ViewContainerRef` of an Element, you can either place a [Directive] injected
 * with `ViewContainerRef` on the Element, or you obtain it via
 * [AppViewManager#getViewContainer].
 *
 * <!-- TODO(i): we are also considering ElementRef#viewContainer api -->
 */
abstract class ViewContainerRef {
  /**
   * Anchor element that specifies the location of this container in the containing View.
   * <!-- TODO: rename to anchorElement -->
   */
  ElementRef get element {
    return (unimplemented() as ElementRef);
  }

  /**
   * Destroys all Views in this container.
   */
  void clear();
  /**
   * Returns the [ViewRef] for the View located in this container at the specified index.
   */
  ViewRef get(num index);
  /**
   * Returns the number of Views currently attached to this container.
   */
  num get length {
    return (unimplemented() as num);
  }

  /**
   * Instantiates an Embedded View based on the [TemplateRef `templateRef`] and inserts it
   * into this container at the specified `index`.
   *
   * If `index` is not specified, the new View will be inserted as the last View in the container.
   *
   * Returns the [ViewRef] for the newly created View.
   */
  EmbeddedViewRef createEmbeddedView(TemplateRef templateRef, [num index]);
  /**
   * Instantiates a single [Component] and inserts its Host View into this container at the
   * specified `index`.
   *
   * The component is instantiated using its [ProtoViewRef `protoView`] which can be
   * obtained via [Compiler#compileInHost].
   *
   * If `index` is not specified, the new View will be inserted as the last View in the container.
   *
   * You can optionally specify `dynamicallyCreatedProviders`, which configure the [Injector]
   * that will be created for the Host View.
   *
   * Returns the [HostViewRef] of the Host View created for the newly instantiated Component.
   */
  HostViewRef createHostView(HostViewFactoryRef hostViewFactoryRef,
      [num index,
      List<ResolvedProvider> dynamicallyCreatedProviders,
      List<List<dynamic>> projectableNodes]);
  /**
   * Inserts a View identified by a [ViewRef] into the container at the specified `index`.
   *
   * If `index` is not specified, the new View will be inserted as the last View in the container.
   *
   * Returns the inserted [ViewRef].
   */
  ViewRef insert(ViewRef viewRef, [num index]);
  /**
   * Returns the index of the View, specified via [ViewRef], within the current container or
   * `-1` if this container doesn't contain the View.
   */
  num indexOf(ViewRef viewRef);
  /**
   * Destroys a View attached to this container at the specified `index`.
   *
   * If `index` is not specified, the last View in the container will be removed.
   */
  void remove([num index]);
  /**
   * Use along with [#insert] to move a View within the current container.
   *
   * If the `index` param is omitted, the last [ViewRef] is detached.
   */
  ViewRef detach([num index]);
}

class ViewContainerRef_ implements ViewContainerRef {
  AppElement _element;
  ViewContainerRef_(this._element) {}
  EmbeddedViewRef get(num index) {
    return this._element.nestedViews[index].ref;
  }

  num get length {
    var views = this._element.nestedViews;
    return isPresent(views) ? views.length : 0;
  }

  ElementRef get element {
    return this._element.ref;
  }

  /** @internal */
  WtfScopeFn _createEmbeddedViewInContainerScope =
      wtfCreateScope("ViewContainerRef#createEmbeddedView()");
  // TODO(rado): profile and decide whether bounds checks should be added

  // to the methods below.
  EmbeddedViewRef createEmbeddedView(TemplateRef templateRef,
      [num index = -1]) {
    var s = this._createEmbeddedViewInContainerScope();
    if (index == -1) index = this.length;
    var templateRef_ = ((templateRef as TemplateRef_));
    AppView<dynamic> view = templateRef_.createEmbeddedView();
    this._element.attachView(view, index);
    return wtfLeave(s, view.ref);
  }

  /** @internal */
  WtfScopeFn _createHostViewInContainerScope =
      wtfCreateScope("ViewContainerRef#createHostView()");
  HostViewRef createHostView(HostViewFactoryRef hostViewFactoryRef,
      [num index = -1,
      List<ResolvedProvider> dynamicallyCreatedProviders = null,
      List<List<dynamic>> projectableNodes = null,
      ElementRef contextElRef = null]) {
    var s = this._createHostViewInContainerScope();
    if (index == -1) index = this.length;
    var contextEl;
    var contextInjector;
    if (isPresent(contextElRef)) {
      contextEl = ((contextElRef as ElementRef_)).internalElement;
      contextInjector = contextEl.defaultInjector;
    } else {
      contextInjector = this._element.parentInjector;
      contextEl = this._element;
    }
    var hostViewFactory =
        ((hostViewFactoryRef as HostViewFactoryRef_)).internalHostViewFactory;
    var childInjector = isPresent(dynamicallyCreatedProviders) &&
            dynamicallyCreatedProviders.length > 0
        ? new Injector_(
            ProtoInjector.fromResolvedProviders(dynamicallyCreatedProviders),
            contextInjector)
        : contextInjector;
    var view = hostViewFactory.viewFactory(contextEl.parentView.viewManager,
        childInjector, contextEl, projectableNodes, null);
    this._element.attachView(view, index);
    return wtfLeave(s, view.ref);
  }

  /** @internal */
  var _insertScope = wtfCreateScope("ViewContainerRef#insert()");
  // TODO(i): refactor insert+remove into move
  ViewRef insert(ViewRef viewRef, [num index = -1]) {
    var s = this._insertScope();
    if (index == -1) index = this.length;
    var viewRef_ = (viewRef as ViewRef_);
    this._element.attachView(viewRef_.internalView, index);
    return wtfLeave(s, viewRef_);
  }

  num indexOf(ViewRef viewRef) {
    return ListWrapper.indexOf(
        this._element.nestedViews, ((viewRef as ViewRef_)).internalView);
  }

  /** @internal */
  var _removeScope = wtfCreateScope("ViewContainerRef#remove()");
  // TODO(i): rename to destroy
  void remove([num index = -1]) {
    var s = this._removeScope();
    if (index == -1) index = this.length - 1;
    var view = this._element.detachView(index);
    view.destroy();
    // view is intentionally not returned to the client.
    wtfLeave(s);
  }

  /** @internal */
  var _detachScope = wtfCreateScope("ViewContainerRef#detach()");
  // TODO(i): refactor insert+remove into move
  ViewRef detach([num index = -1]) {
    var s = this._detachScope();
    if (index == -1) index = this.length - 1;
    var view = this._element.detachView(index);
    return wtfLeave(s, view.ref);
  }

  clear() {
    for (var i = this.length - 1; i >= 0; i--) {
      this.remove(i);
    }
  }
}
