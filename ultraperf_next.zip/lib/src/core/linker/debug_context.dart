library angular2.src.core.linker.debug_context;

import "package:angular2/src/facade/lang.dart" show isPresent, isBlank;
import "package:angular2/src/facade/collection.dart"
    show ListWrapper, StringMapWrapper;
import "package:angular2/src/core/di.dart" show Injector;
import "package:angular2/src/core/render/api.dart" show RenderDebugInfo;
import "view.dart" show AppView;
import "view_type.dart" show ViewType;

class StaticNodeDebugInfo {
  final String source;
  final List<dynamic> providerTokens;
  final dynamic componentToken;
  final Map<String, dynamic> varTokens;
  const StaticNodeDebugInfo(
      this.source, this.providerTokens, this.componentToken, this.varTokens);
}

class StaticBindingDebugInfo {
  final String source;
  const StaticBindingDebugInfo(this.source);
}

class DebugContext implements RenderDebugInfo {
  AppView<dynamic> _view;
  num nodeIndex;
  num bindingIndex;
  DebugContext(this._view, [this.nodeIndex = null, this.bindingIndex = null]) {}
  StaticNodeDebugInfo get _staticNodeInfo {
    return isPresent(this.nodeIndex)
        ? this._view.staticNodeDebugInfos[this.nodeIndex]
        : null;
  }

  StaticBindingDebugInfo get _staticBindingInfo {
    return isPresent(this.bindingIndex)
        ? this._view.staticBindingDebugInfos[this.bindingIndex]
        : null;
  }

  get context {
    return this._view.context;
  }

  get component {
    var staticNodeInfo = this._staticNodeInfo;
    if (isPresent(staticNodeInfo) && isPresent(staticNodeInfo.componentToken)) {
      return this.injector.get(staticNodeInfo.componentToken);
    } else if (this.providerTokens.length > 0) {
      // TODO(tbosch): This was a bug in the old implementation that we

      // keep for now to land the big codegen PR.

      // clean this up later!
      return this.injector.get(this.providerTokens[0]);
    }
    return this.context;
  }

  get componentRenderElement {
    var componentView = this._view;
    while (isPresent(componentView.declarationAppElement) &&
        !identical(componentView.type, ViewType.COMPONENT)) {
      componentView = componentView.declarationAppElement.parentView;
    }
    return isPresent(componentView.declarationAppElement)
        ? componentView.declarationAppElement.nativeElement
        : null;
  }

  Injector get injector {
    return this._view.injector(this.nodeIndex, true);
  }

  dynamic get renderNode {
    if (isPresent(this.nodeIndex)) {
      return this._view.allNodes[this.nodeIndex];
    } else {
      return null;
    }
  }

  List<dynamic> get providerTokens {
    var staticNodeInfo = this._staticNodeInfo;
    return isPresent(staticNodeInfo) ? staticNodeInfo.providerTokens : null;
  }

  String get nodeSource {
    var staticNodeInfo = this._staticNodeInfo;
    return isPresent(staticNodeInfo) ? staticNodeInfo.source : null;
  }

  String get source {
    var sourceStack = [];
    DebugContext ctx = this;
    var view = this._view;
    while (isPresent(ctx)) {
      if (identical(sourceStack.length, 0) ||
          identical(view.type, ViewType.COMPONENT)) {
        sourceStack.add(
            isPresent(ctx.bindingSource) ? ctx.bindingSource : ctx.nodeSource);
      }
      if (isPresent(view.declarationAppElement)) {
        ctx = view.declarationAppElement.debugContext;
        view = view.declarationAppElement.parentView;
      } else {
        ctx = null;
      }
    }
    return sourceStack.join("\n in component ");
  }

  Map<String, String> get locals {
    Map<String, String> varValues = {};
    // TODO(tbosch): right now, the semantics of debugNode.locals are

    // that it contains the variables of all elements, not just

    // the given one. We preserve this for now to not have a breaking

    // change, but should change this later!
    ListWrapper.forEachWithIndex(this._view.staticNodeDebugInfos,
        (StaticNodeDebugInfo staticNodeInfo, num nodeIndex) {
      var vars = staticNodeInfo.varTokens;
      StringMapWrapper.forEach(vars, (varToken, varName) {
        var varValue;
        if (isBlank(varToken)) {
          varValue = this._view.allNodes[nodeIndex];
        } else {
          varValue = this._view.injectorGet(varToken, nodeIndex, null);
        }
        varValues[varName] = varValue;
      });
    });
    StringMapWrapper.forEach(this._view.locals, (localValue, localName) {
      varValues[localName] = localValue;
    });
    return varValues;
  }

  String get bindingSource {
    var staticBindingInfo = this._staticBindingInfo;
    return isPresent(staticBindingInfo) ? staticBindingInfo.source : null;
  }
}
