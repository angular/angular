library angular2.src.core.linker.element_injector;

import "package:angular2/src/facade/lang.dart" show isBlank, stringify;
import "package:angular2/src/facade/exceptions.dart" show BaseException;
import "package:angular2/src/core/di/injector.dart" show Injector, UNDEFINED;
import "view.dart" show AppView;

class ElementInjector extends Injector {
  AppView<dynamic> _view;
  num _nodeIndex;
  bool _readPrivate;
  ElementInjector(this._view, this._nodeIndex, this._readPrivate) : super() {
    /* super call moved to initializer */;
  }
  dynamic _getFromView(dynamic token) {
    var result = UNDEFINED;
    if (this._readPrivate) {
      result = this._view.injectorPrivateGet(token, this._nodeIndex, UNDEFINED);
    }
    if (identical(result, UNDEFINED)) {
      result = this._view.injectorGet(token, this._nodeIndex, UNDEFINED);
    }
    return result;
  }

  dynamic get(dynamic token) {
    try {
      var result = this._getFromView(token);
      if (identical(result, UNDEFINED)) {
        result = this._view.parentInjector.get(token);
      }
      return result;
    } catch (e, e_stack) {
      this._view.rethrowWithContext("inject", this.debugContext(), e, e_stack);
    }
  }

  dynamic getOptional(dynamic token) {
    try {
      var result = this._getFromView(token);
      if (identical(result, UNDEFINED)) {
        result = this._view.parentInjector.getOptional(token);
      }
      return result;
    } catch (e, e_stack) {
      this._view.rethrowWithContext("inject", this.debugContext(), e, e_stack);
    }
  }

  dynamic debugContext() {
    return this._view.debugContext(this._nodeIndex, null);
  }
}
