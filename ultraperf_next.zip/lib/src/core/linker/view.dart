library angular2.src.core.linker.view;

import "package:angular2/src/facade/collection.dart"
    show
        ListWrapper,
        MapWrapper,
        Map,
        StringMapWrapper,
        isListLikeIterable,
        areIterablesEqual;
import "package:angular2/src/core/di.dart" show Injector;
import "element.dart" show AppElement;
import "package:angular2/src/facade/lang.dart"
    show
        assertionsEnabled,
        isPresent,
        isBlank,
        Type,
        isArray,
        isNumber,
        stringify,
        looseIdentical,
        isPrimitive;
import "package:angular2/src/facade/async.dart" show ObservableWrapper;
import "package:angular2/src/core/render/api.dart"
    show Renderer, RootRenderer, RenderDebugInfo;
import "view_ref.dart" show ViewRef_, HostViewFactoryRef;
import "view_manager.dart" show AppViewManager_, AppViewManager;
import "view_type.dart" show ViewType;
import "view_utils.dart" show flattenNestedViewRenderNodes;
import "package:angular2/src/core/change_detection/change_detection.dart"
    show
        ChangeDetectorRef,
        ChangeDetectionStrategy,
        ChangeDetectorState,
        isDefaultChangeDetectionStrategy;
import "../profile/profile.dart" show wtfCreateScope, wtfLeave, WtfScopeFn;
import "exceptions.dart"
    show
        ViewWrappedException,
        ExpressionChangedAfterItHasBeenCheckedException,
        ViewDestroyedException;
import "debug_context.dart"
    show StaticNodeDebugInfo, StaticBindingDebugInfo, DebugContext;
import "element_injector.dart" show ElementInjector;

const HOST_VIEW_ELEMENT_NAME = "\$hostViewEl";
const EMPTY_CONTEXT = const Object();
WtfScopeFn _scope_check = wtfCreateScope('''AppView#check(ascii id)''');

/**
 * Cost of making objects: http://jsperf.com/instantiate-size-of-object
 *
 */
abstract class AppView<T> {
  dynamic clazz;
  ViewType type;
  Map<String, dynamic> locals;
  Renderer renderer;
  AppViewManager_ viewManager;
  Injector parentInjector;
  List<dynamic /* dynamic | List < dynamic > */ > projectableNodes;
  AppElement declarationAppElement;
  List<StaticNodeDebugInfo> staticNodeDebugInfos;
  List<StaticBindingDebugInfo> staticBindingDebugInfos;
  ViewRef_ ref;
  List<dynamic> rootNodesOrAppElements;
  List<dynamic> allNodes;
  List<Function> disposables;
  List<dynamic> subscriptions;
  Map<String, AppElement> namedAppElements;
  List<AppView<dynamic>> contentChildren = [];
  List<AppView<dynamic>> viewChildren = [];
  AppView<dynamic> renderParent;
  // The names of the below fields must be kept in sync with codegen_name_util.ts or

  // change detection will fail.
  ChangeDetectorState state = ChangeDetectorState.NeverChecked;
  ChangeDetectionStrategy mode;
  /**
   * The context against which data-binding expressions in this view are evaluated against.
   * This is always a component instance.
   */
  T context = null;
  bool destroyed = false;
  AppView(
      this.clazz,
      this.type,
      this.locals,
      this.renderer,
      this.viewManager,
      this.parentInjector,
      this.projectableNodes,
      this.declarationAppElement,
      ChangeDetectionStrategy strategy,
      this.staticNodeDebugInfos,
      this.staticBindingDebugInfos) {
    this.ref = new ViewRef_(this);
    var context;
    var mode = ChangeDetectionStrategy.CheckAlways;
    switch (this.type) {
      case ViewType.COMPONENT:
        context = this.declarationAppElement.component;
        mode = isDefaultChangeDetectionStrategy(strategy)
            ? ChangeDetectionStrategy.CheckAlways
            : ChangeDetectionStrategy.CheckOnce;
        break;
      case ViewType.EMBEDDED:
        context = this.declarationAppElement.parentView.context;
        break;
      case ViewType.HOST:
        context = EMPTY_CONTEXT;
        break;
    }
    this.context = context;
    this.mode = mode;
    this.state = ChangeDetectorState.NeverChecked;
  }
  init(
      List<dynamic> rootNodesOrAppElements,
      List<dynamic> allNodes,
      Map<String, AppElement> appElements,
      List<Function> disposables,
      List<dynamic> subscriptions,
      bool hadError) {
    this.rootNodesOrAppElements = rootNodesOrAppElements;
    this.allNodes = allNodes;
    this.namedAppElements = appElements;
    this.disposables = disposables;
    this.subscriptions = subscriptions;
    if (!hadError) {
      if (identical(this.type, ViewType.COMPONENT)) {
        // Note: the render nodes have been attached to their host element

        // in the ViewFactory already.
        this.declarationAppElement.initComponentView(this);
        this.declarationAppElement.parentView.viewChildren.add(this);
        this.renderParent = this.declarationAppElement.parentView;
        this.dirtyParentQueriesInternal();
      }
    }
  }

  AppElement getHostViewElement() {
    return this.namedAppElements[HOST_VIEW_ELEMENT_NAME];
  }

  /**
   * Overwritten by implementations
   */
  dynamic injectorGet(dynamic token, num nodeIndex, dynamic notFoundResult) {
    return notFoundResult;
  }

  /**
   * Overwritten by implementations
   */
  dynamic injectorPrivateGet(
      dynamic token, num nodeIndex, dynamic notFoundResult) {
    return notFoundResult;
  }

  Injector injector(num nodeIndex, bool readPrivate) {
    if (isPresent(nodeIndex)) {
      return new ElementInjector(this, nodeIndex, readPrivate);
    } else {
      return this.parentInjector;
    }
  }

  destroy() {
    if (this.destroyed) {
      return;
    }
    var children = this.contentChildren;
    for (var i = 0; i < children.length; i++) {
      children[i].destroy();
    }
    children = this.viewChildren;
    for (var i = 0; i < children.length; i++) {
      children[i].destroy();
    }
    var hostElement = identical(this.type, ViewType.COMPONENT)
        ? this.declarationAppElement.nativeElement
        : null;
    this.renderer.destroyView(hostElement, this.allNodes);
    for (var i = 0; i < this.disposables.length; i++) {
      this.disposables[i]();
    }
    for (var i = 0; i < this.subscriptions.length; i++) {
      ObservableWrapper.dispose(this.subscriptions[i]);
    }
    this.destroyInternal();
    this.dirtyParentQueriesInternal();
    this.destroyed = true;
  }

  /**
   * Overwritten by implementations
   */
  void destroyInternal() {}
  ChangeDetectorRef get changeDetectorRef {
    return this.ref;
  }

  List<dynamic> get flatRootNodes {
    return flattenNestedViewRenderNodes(this.rootNodesOrAppElements);
  }

  dynamic get lastRootNode {
    var lastNode = this.rootNodesOrAppElements.length > 0
        ? this.rootNodesOrAppElements[this.rootNodesOrAppElements.length - 1]
        : null;
    return _findLastRenderNode(lastNode);
  }

  bool hasLocal(String contextName) {
    return StringMapWrapper.contains(this.locals, contextName);
  }

  void setLocal(String contextName, dynamic value) {
    this.locals[contextName] = value;
  }

  /**
   * Overwritten by implementations
   */
  void afterContentLifecycleCallbacksInternal() {}
  /**
   * Overwritten by implementations
   */
  void updateContentQueriesInternal() {}
  /**
   * Overwritten by implementations
   */
  void afterViewLifecycleCallbacksInternal() {}
  /**
   * Overwritten by implementations
   */
  void updateViewQueriesInternal() {}
  /**
   * Overwritten by implementations
   */
  void dirtyParentQueriesInternal() {}
  void addRenderContentChild(AppView<dynamic> view) {
    this.contentChildren.add(view);
    view.renderParent = this;
    view.dirtyParentQueriesInternal();
  }

  void removeContentChild(AppView<dynamic> view) {
    ListWrapper.remove(this.contentChildren, view);
    view.dirtyParentQueriesInternal();
    view.renderParent = null;
  }

  void detectChanges() {
    var s = _scope_check(this.clazz);
    if (identical(this.mode, ChangeDetectionStrategy.Detached) ||
        identical(this.mode, ChangeDetectionStrategy.Checked) ||
        identical(this.state, ChangeDetectorState.Errored)) return;
    if (this.destroyed) {
      this.throwDestroyedError("detectChanges");
    }
    this.detectChangesInInputsInternal();
    for (var i = 0; i < this.contentChildren.length; ++i) {
      this.contentChildren[i].detectChanges();
    }
    this.updateContentQueriesInternal();
    this.afterContentLifecycleCallbacksInternal();
    this.detectChangesHostPropertiesInternal();
    for (var i = 0; i < this.viewChildren.length; ++i) {
      this.viewChildren[i].detectChanges();
    }
    this.updateViewQueriesInternal();
    this.afterViewLifecycleCallbacksInternal();
    if (identical(this.mode, ChangeDetectionStrategy.CheckOnce))
      this.mode = ChangeDetectionStrategy.Checked;
    this.state = ChangeDetectorState.CheckedBefore;
    wtfLeave(s);
  }

  void checkNoChanges() {
    if (!assertionsEnabled()) return;
    if (identical(this.mode, ChangeDetectionStrategy.Detached) ||
        identical(this.mode, ChangeDetectionStrategy.Checked) ||
        identical(this.state, ChangeDetectorState.Errored)) return;
    if (this.destroyed) {
      this.throwDestroyedError("checkNoChanges");
    }
    this.checkNoChangesInternal();
    for (var i = 0; i < this.contentChildren.length; ++i) {
      this.contentChildren[i].checkNoChanges();
    }
    for (var i = 0; i < this.viewChildren.length; ++i) {
      this.viewChildren[i].checkNoChanges();
    }
  }

  /**
   * Overwritten by implementations
   */
  void detectChangesInInputsInternal() {}
  /**
   * Overwritten by implementations
   */
  void detectChangesHostPropertiesInternal() {}
  /**
   * Overwritten by implementations
   */
  void checkNoChangesInternal() {}
  void markAsCheckOnce() {
    this.mode = ChangeDetectionStrategy.CheckOnce;
  }

  void markPathToRootAsCheckOnce() {
    AppView<dynamic> c = this;
    while (
        isPresent(c) && !identical(c.mode, ChangeDetectionStrategy.Detached)) {
      if (identical(c.mode, ChangeDetectionStrategy.Checked)) {
        c.mode = ChangeDetectionStrategy.CheckOnce;
      }
      c = c.renderParent;
    }
  }

  DebugContext debugContext(num nodeIndex, num bindingIndex) {
    return new DebugContext(this, nodeIndex, bindingIndex);
  }

  void throwOnChangeError(
      DebugContext debugCtx, dynamic oldValue, dynamic newValue) {
    throw new ExpressionChangedAfterItHasBeenCheckedException(
        debugCtx.bindingSource, oldValue, newValue, null);
  }

  rethrowWithContext(
      String methodName, DebugContext debugCtx, dynamic e, dynamic stack) {
    if ((e is ViewWrappedException)) {
      throw e;
    }
    if (!(e is ExpressionChangedAfterItHasBeenCheckedException)) {
      this.state = ChangeDetectorState.Errored;
    }
    throw new ViewWrappedException(methodName, e, stack, debugCtx);
  }

  void throwDestroyedError(String details) {
    throw new ViewDestroyedException(details);
  }
}

class HostViewFactory {
  final String selector;
  final Function viewFactory;
  const HostViewFactory(this.selector, this.viewFactory);
}

dynamic _findLastRenderNode(dynamic node) {
  var lastNode;
  if (node is AppElement) {
    var appEl = (node as AppElement);
    lastNode = appEl.nativeElement;
    if (isPresent(appEl.nestedViews)) {
      // Note: Views might have no root nodes at all!
      for (var i = appEl.nestedViews.length - 1; i >= 0; i--) {
        var nestedView = appEl.nestedViews[i];
        if (nestedView.rootNodesOrAppElements.length > 0) {
          lastNode = _findLastRenderNode(nestedView.rootNodesOrAppElements[
              nestedView.rootNodesOrAppElements.length - 1]);
        }
      }
    }
  } else {
    lastNode = node;
  }
  return lastNode;
}
