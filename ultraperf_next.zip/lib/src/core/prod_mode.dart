library angular2.src.core.prod_mode;

export "package:angular2/src/facade/lang.dart" show enableProdMode;
