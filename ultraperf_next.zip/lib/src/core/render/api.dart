library angular2.src.core.render.api;

import "package:angular2/src/facade/exceptions.dart" show unimplemented;
import "package:angular2/src/core/metadata/view.dart" show ViewEncapsulation;
import "package:angular2/src/core/di.dart" show Injector, Injectable;

class RenderComponentType {
  String id;
  ViewEncapsulation encapsulation;
  List<dynamic /* String | List < dynamic > */ > styles;
  RenderComponentType(this.id, this.encapsulation, this.styles) {}
}

abstract class RenderDebugInfo {
  Injector get injector {
    return unimplemented();
  }

  dynamic get component {
    return unimplemented();
  }

  List<dynamic> get providerTokens {
    return unimplemented();
  }

  Map<String, String> get locals {
    return unimplemented();
  }

  String get source {
    return unimplemented();
  }
}

abstract class Renderer {
  dynamic selectRootElement(String selector, RenderDebugInfo debugInfo);
  dynamic createElement(
      dynamic parentElement, String name, RenderDebugInfo debugInfo);
  dynamic createViewRoot(dynamic hostElement);
  dynamic createTemplateAnchor(
      dynamic parentElement, RenderDebugInfo debugInfo);
  dynamic createText(
      dynamic parentElement, String value, RenderDebugInfo debugInfo);
  projectNodes(dynamic parentElement, List<dynamic> nodes);
  attachViewAfter(dynamic node, List<dynamic> viewRootNodes);
  detachView(List<dynamic> viewRootNodes);
  destroyView(dynamic hostElement, List<dynamic> viewAllNodes);
  Function listen(dynamic renderElement, String name, Function callback);
  Function listenGlobal(String target, String name, Function callback);
  setElementProperty(
      dynamic renderElement, String propertyName, dynamic propertyValue);
  setElementAttribute(
      dynamic renderElement, String attributeName, String attributeValue);
  /**
   * Used only in debug mode to serialize property changes to dom nodes as attributes.
   */
  setBindingDebugInfo(
      dynamic renderElement, String propertyName, String propertyValue);
  setElementClass(dynamic renderElement, String className, bool isAdd);
  setElementStyle(dynamic renderElement, String styleName, String styleValue);
  invokeElementMethod(
      dynamic renderElement, String methodName, List<dynamic> args);
  setText(dynamic renderNode, String text);
}

/**
 * Injectable service that provides a low-level interface for modifying the UI.
 *
 * Use this service to bypass Angular's templating and make custom UI changes that can't be
 * expressed declaratively. For example if you need to set a property or an attribute whose name is
 * not statically known, use [#setElementProperty] or [#setElementAttribute]
 * respectively.
 *
 * If you are implementing a custom renderer, you must implement this interface.
 *
 * The default Renderer implementation is `DomRenderer`. Also available is `WebWorkerRenderer`.
 */
abstract class RootRenderer {
  Renderer renderComponent(RenderComponentType componentType);
}
