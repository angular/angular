@Deprecated('import this from "package:angular2/platform/common_dom.dart"')
library angular2.dom_adapter_reexport;

export 'package:angular2/src/platform/dom/dom_adapter.dart';
