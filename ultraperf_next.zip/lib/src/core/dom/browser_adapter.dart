@Deprecated(
    'import this library from "package:angular2/platform/browser_static.dart"')
library angular2.browser_adapter_reexport;

export 'package:angular2/src/platform/browser/browser_adapter.dart';
