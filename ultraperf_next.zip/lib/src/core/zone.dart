// Public API for Zone
library angular2.src.core.zone;

export "zone/ng_zone.dart" show NgZone, NgZoneError;
