library angular2.src.dom.parse5_adapter;

// no dart implementation
