library angular2.testing.perf_util;

// empty as this file is node.js specific and should not be transpiled to dart
