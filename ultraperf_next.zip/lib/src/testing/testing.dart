library angular2.src.testing.testing;

// empty as this file is for external TS/js users and should not be transpiled to dart
