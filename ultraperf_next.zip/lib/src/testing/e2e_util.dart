library angular2.e2e_util;

// empty as this file is node.js specific and should not be transpiled to dart
