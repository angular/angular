/**
 * This indirection is needed for TS compilation path.
 * See comment in lifecycle_annotations.ts.
 */

library angular2.router.lifecycle_annotations;

export "./lifecycle_annotations_impl.dart";
