library angular2.router.route_config_decorator;

export './route_config_impl.dart';
