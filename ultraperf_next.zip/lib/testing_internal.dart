// Test library and utilities for internal use.
library angular2.testing_internal;

export "src/testing/testing_internal.dart";
export "src/testing/test_component_builder.dart";
export "src/testing/test_injector.dart";
export "src/testing/fake_async.dart";
export "src/testing/utils.dart";
