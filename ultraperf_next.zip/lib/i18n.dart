/**
 * 
 * 
 * Entry point to i18n
 */
library angular2.i18n;

export "src/i18n/message.dart";
export "src/i18n/xmb_serializer.dart";
export "src/i18n/message_extractor.dart";
export "src/i18n/i18n_html_parser.dart";
