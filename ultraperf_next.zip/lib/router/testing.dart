library angular2.router.testing;

export "package:angular2/src/mock/mock_location_strategy.dart";
export "package:angular2/src/mock/location_mock.dart";
